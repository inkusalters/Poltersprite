<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Player Sprite" tilewidth="16" tileheight="16" tilecount="9" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../Documents/Something/assets/sprites/player side.png" width="16" height="16"/>
 </tile>
 <tile id="1">
  <image source="../../Documents/Something/assets/sprites/player back step2.png" width="16" height="16"/>
 </tile>
 <tile id="2">
  <image source="../../Documents/Something/assets/sprites/player side step2.png" width="16" height="16"/>
 </tile>
 <tile id="3">
  <image source="../../Documents/Something/assets/sprites/player side step1.png" width="16" height="16"/>
 </tile>
 <tile id="4">
  <image source="../../Documents/Something/assets/sprites/player front step2.png" width="16" height="16"/>
 </tile>
 <tile id="5">
  <image source="../../Documents/Something/assets/sprites/player front step1.png" width="16" height="16"/>
 </tile>
 <tile id="6">
  <image source="../../Documents/Something/assets/sprites/player front.png" width="16" height="16"/>
 </tile>
 <tile id="7">
  <image source="../../Documents/Something/assets/sprites/player back.png" width="16" height="16"/>
 </tile>
 <tile id="8">
  <image source="../../Documents/Something/assets/sprites/player back step1.png" width="16" height="16"/>
 </tile>
</tileset>

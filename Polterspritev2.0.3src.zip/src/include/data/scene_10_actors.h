#ifndef SCENE_10_ACTORS_H
#define SCENE_10_ACTORS_H

// Scene: Notebook
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_10_actors)
extern const struct actor_t scene_10_actors[];

#endif

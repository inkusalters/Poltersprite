#ifndef SCENE_12_SPRITES_H
#define SCENE_12_SPRITES_H

// Scene: Entrance
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_12_sprites)
extern const far_ptr_t scene_12_sprites[];

#endif

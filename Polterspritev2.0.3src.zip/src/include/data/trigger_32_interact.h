#ifndef TRIGGER_32_INTERACT_H
#define TRIGGER_32_INTERACT_H

// Script trigger_32_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_32_interact)
extern const unsigned char trigger_32_interact[];

#endif

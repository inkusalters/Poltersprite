#ifndef ACTOR_12_UPDATE_H
#define ACTOR_12_UPDATE_H

// Script actor_12_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_12_update)
extern const unsigned char actor_12_update[];

#endif

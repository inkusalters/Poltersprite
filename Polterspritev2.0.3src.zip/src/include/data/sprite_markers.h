#ifndef SPRITE_MARKERS_H
#define SPRITE_MARKERS_H

// SpriteSheet: markers

#include "gbs_types.h"

BANKREF_EXTERN(sprite_markers)
extern const struct spritesheet_t sprite_markers;

#endif

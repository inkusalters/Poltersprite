#ifndef SPRITE_EQUIPMENTV2_TILESET_H
#define SPRITE_EQUIPMENTV2_TILESET_H

// Tileset: sprite_equipmentv2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_equipmentv2_tileset)
extern const struct tileset_t sprite_equipmentv2_tileset;

#endif

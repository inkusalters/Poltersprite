#ifndef ACTOR_48_UPDATE_H
#define ACTOR_48_UPDATE_H

// Script actor_48_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_48_update)
extern const unsigned char actor_48_update[];

#endif

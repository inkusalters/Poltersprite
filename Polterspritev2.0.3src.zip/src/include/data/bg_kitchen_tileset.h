#ifndef BG_KITCHEN_TILESET_H
#define BG_KITCHEN_TILESET_H

// Tileset: bg_kitchen_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_kitchen_tileset)
extern const struct tileset_t bg_kitchen_tileset;

#endif

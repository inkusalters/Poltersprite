#ifndef ACTOR_24_UPDATE_H
#define ACTOR_24_UPDATE_H

// Script actor_24_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_24_update)
extern const unsigned char actor_24_update[];

#endif

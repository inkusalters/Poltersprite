#ifndef SCRIPT_8_H
#define SCRIPT_8_H

// Script script_8

#include "gbs_types.h"

BANKREF_EXTERN(script_8)
extern const unsigned char script_8[];

#endif

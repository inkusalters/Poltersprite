#ifndef TRIGGER_55_INTERACT_H
#define TRIGGER_55_INTERACT_H

// Script trigger_55_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_55_interact)
extern const unsigned char trigger_55_interact[];

#endif

#ifndef ACTOR_61_INTERACT_H
#define ACTOR_61_INTERACT_H

// Script actor_61_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_61_interact)
extern const unsigned char actor_61_interact[];

#endif

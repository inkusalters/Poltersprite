#ifndef BG_FERRIS_WHEEL_TILESET_H
#define BG_FERRIS_WHEEL_TILESET_H

// Tileset: bg_ferris_wheel_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_ferris_wheel_tileset)
extern const struct tileset_t bg_ferris_wheel_tileset;

#endif

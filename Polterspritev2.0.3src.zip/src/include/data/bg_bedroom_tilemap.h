#ifndef BG_BEDROOM_TILEMAP_H
#define BG_BEDROOM_TILEMAP_H

// Tilemap bg_bedroom_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_bedroom_tilemap)
extern const unsigned char bg_bedroom_tilemap[];

#endif

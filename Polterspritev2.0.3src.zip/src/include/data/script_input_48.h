#ifndef SCRIPT_INPUT_48_H
#define SCRIPT_INPUT_48_H

// Script script_input_48

#include "gbs_types.h"

BANKREF_EXTERN(script_input_48)
extern const unsigned char script_input_48[];

#endif

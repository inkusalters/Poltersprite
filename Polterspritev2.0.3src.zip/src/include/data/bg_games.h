#ifndef BG_GAMES_H
#define BG_GAMES_H

// Background: games

#include "gbs_types.h"

BANKREF_EXTERN(bg_games)
extern const struct background_t bg_games;

#endif

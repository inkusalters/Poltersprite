#ifndef TRIGGER_26_INTERACT_H
#define TRIGGER_26_INTERACT_H

// Script trigger_26_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_26_interact)
extern const unsigned char trigger_26_interact[];

#endif

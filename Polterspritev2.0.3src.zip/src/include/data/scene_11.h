#ifndef SCENE_11_H
#define SCENE_11_H

// Scene: Game Over

#include "gbs_types.h"

BANKREF_EXTERN(scene_11)
extern const struct scene_t scene_11;

#endif

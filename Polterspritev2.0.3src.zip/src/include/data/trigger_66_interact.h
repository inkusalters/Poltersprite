#ifndef TRIGGER_66_INTERACT_H
#define TRIGGER_66_INTERACT_H

// Script trigger_66_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_66_interact)
extern const unsigned char trigger_66_interact[];

#endif

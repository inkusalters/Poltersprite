#ifndef TRIGGER_63_INTERACT_H
#define TRIGGER_63_INTERACT_H

// Script trigger_63_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_63_interact)
extern const unsigned char trigger_63_interact[];

#endif

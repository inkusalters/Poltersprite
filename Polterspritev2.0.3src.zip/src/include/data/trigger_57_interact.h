#ifndef TRIGGER_57_INTERACT_H
#define TRIGGER_57_INTERACT_H

// Script trigger_57_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_57_interact)
extern const unsigned char trigger_57_interact[];

#endif

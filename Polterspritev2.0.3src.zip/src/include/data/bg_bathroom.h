#ifndef BG_BATHROOM_H
#define BG_BATHROOM_H

// Background: bathroom

#include "gbs_types.h"

BANKREF_EXTERN(bg_bathroom)
extern const struct background_t bg_bathroom;

#endif

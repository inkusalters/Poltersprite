#ifndef ACTOR_62_UPDATE_H
#define ACTOR_62_UPDATE_H

// Script actor_62_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_62_update)
extern const unsigned char actor_62_update[];

#endif

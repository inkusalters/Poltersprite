#ifndef TRIGGER_34_INTERACT_H
#define TRIGGER_34_INTERACT_H

// Script trigger_34_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_34_interact)
extern const unsigned char trigger_34_interact[];

#endif

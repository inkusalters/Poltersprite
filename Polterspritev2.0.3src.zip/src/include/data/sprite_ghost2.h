#ifndef SPRITE_GHOST2_H
#define SPRITE_GHOST2_H

// SpriteSheet: ghost2

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ghost2)
extern const struct spritesheet_t sprite_ghost2;

#endif

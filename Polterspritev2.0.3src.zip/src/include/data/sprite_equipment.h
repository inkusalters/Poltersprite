#ifndef SPRITE_EQUIPMENT_H
#define SPRITE_EQUIPMENT_H

// SpriteSheet: equipment

#include "gbs_types.h"

BANKREF_EXTERN(sprite_equipment)
extern const struct spritesheet_t sprite_equipment;

#endif

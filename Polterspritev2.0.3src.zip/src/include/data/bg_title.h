#ifndef BG_TITLE_H
#define BG_TITLE_H

// Background: title

#include "gbs_types.h"

BANKREF_EXTERN(bg_title)
extern const struct background_t bg_title;

#endif

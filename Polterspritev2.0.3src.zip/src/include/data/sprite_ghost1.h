#ifndef SPRITE_GHOST1_H
#define SPRITE_GHOST1_H

// SpriteSheet: ghost1

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ghost1)
extern const struct spritesheet_t sprite_ghost1;

#endif

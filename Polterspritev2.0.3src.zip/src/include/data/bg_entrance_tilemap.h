#ifndef BG_ENTRANCE_TILEMAP_H
#define BG_ENTRANCE_TILEMAP_H

// Tilemap bg_entrance_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_entrance_tilemap)
extern const unsigned char bg_entrance_tilemap[];

#endif

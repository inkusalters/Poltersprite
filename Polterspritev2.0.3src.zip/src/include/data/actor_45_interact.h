#ifndef ACTOR_45_INTERACT_H
#define ACTOR_45_INTERACT_H

// Script actor_45_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_45_interact)
extern const unsigned char actor_45_interact[];

#endif

#ifndef SCRIPT_INPUT_36_H
#define SCRIPT_INPUT_36_H

// Script script_input_36

#include "gbs_types.h"

BANKREF_EXTERN(script_input_36)
extern const unsigned char script_input_36[];

#endif

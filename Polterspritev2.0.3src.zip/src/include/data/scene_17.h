#ifndef SCENE_17_H
#define SCENE_17_H

// Scene: Ferris Wheel

#include "gbs_types.h"

BANKREF_EXTERN(scene_17)
extern const struct scene_t scene_17;

#endif

#ifndef ACTOR_21_UPDATE_H
#define ACTOR_21_UPDATE_H

// Script actor_21_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_21_update)
extern const unsigned char actor_21_update[];

#endif

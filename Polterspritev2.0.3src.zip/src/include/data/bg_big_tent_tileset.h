#ifndef BG_BIG_TENT_TILESET_H
#define BG_BIG_TENT_TILESET_H

// Tileset: bg_big_tent_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_big_tent_tileset)
extern const struct tileset_t bg_big_tent_tileset;

#endif

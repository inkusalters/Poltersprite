#ifndef SCENE_6_ACTORS_H
#define SCENE_6_ACTORS_H

// Scene: Bathroom
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_6_actors)
extern const struct actor_t scene_6_actors[];

#endif

#ifndef BG_KITCHEN_TILEMAP_H
#define BG_KITCHEN_TILEMAP_H

// Tilemap bg_kitchen_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_kitchen_tilemap)
extern const unsigned char bg_kitchen_tilemap[];

#endif

#ifndef SCENE_11_COLLISIONS_H
#define SCENE_11_COLLISIONS_H

// Scene: Game Over
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_11_collisions)
extern const unsigned char scene_11_collisions[];

#endif

#ifndef SCENE_0_COLLISIONS_H
#define SCENE_0_COLLISIONS_H

// Scene: Ghosts
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_0_collisions)
extern const unsigned char scene_0_collisions[];

#endif

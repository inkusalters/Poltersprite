#include <gbdk/platform.h>

// System fields
UBYTE _is_CGB, _is_SGB;
volatile UBYTE _current_ram_bank;
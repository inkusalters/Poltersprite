#pragma bank 255

// Background: ferris wheel

#include "gbs_types.h"
#include "data/bg_ferris_wheel_tileset.h"
#include "data/bg_ferris_wheel_tilemap.h"

BANKREF(bg_ferris_wheel)

const struct background_t bg_ferris_wheel = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_ferris_wheel_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_ferris_wheel_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

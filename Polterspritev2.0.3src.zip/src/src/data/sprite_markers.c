#pragma bank 255
// SpriteSheet: markers

#include "gbs_types.h"
#include "data/sprite_markers_tileset.h"


BANKREF(sprite_markers)

#define SPRITE_12_STATE_DEFAULT 0
#define SPRITE_12_STATE_A_BUTTON 0
#define SPRITE_12_STATE_B_BUTTON 0
#define SPRITE_12_STATE_HANDPRINT 0
#define SPRITE_12_STATE_CUP_UPRIGHT 0
#define SPRITE_12_STATE_CUP_KNOCKED 0
#define SPRITE_12_STATE_FRAME_UPRIGHT 0
#define SPRITE_12_STATE_FRAME_KNOCKED 0
#define SPRITE_12_STATE_BONE 0
#define SPRITE_12_STATE_SKULL 0
#define SPRITE_12_STATE_BOOK 0
#define SPRITE_12_STATE_EMF 0
#define SPRITE_12_STATE_SPIRIT_BOX 0
#define SPRITE_12_STATE_NIGHT_VISION 0
#define SPRITE_12_STATE_THERMOMETER 0
#define SPRITE_12_STATE_CHECKED 0
#define SPRITE_12_STATE_LOSE 0
#define SPRITE_12_STATE_WIN 0
#define SPRITE_12_STATE_BOXO 0
#define SPRITE_12_STATE_BLOT 8
#define SPRITE_12_STATE_MARK 16

const metasprite_t sprite_markers_metasprite_0[]  = {
    {metasprite_end}
};

const metasprite_t sprite_markers_metasprite_1[]  = {
    { 0, 8, 2, 0 }, { 0, -8, 4, 0 },
    {metasprite_end}
};

const metasprite_t sprite_markers_metasprite_2[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 0, 32 },
    {metasprite_end}
};

const metasprite_t * const sprite_markers_metasprites[] = {
    sprite_markers_metasprite_0,
    sprite_markers_metasprite_1,
    sprite_markers_metasprite_2
};

const struct animation_t sprite_markers_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    }
};

const UWORD sprite_markers_animations_lookup[] = {
    SPRITE_12_STATE_DEFAULT,
    SPRITE_12_STATE_A_BUTTON,
    SPRITE_12_STATE_B_BUTTON,
    SPRITE_12_STATE_HANDPRINT,
    SPRITE_12_STATE_CUP_UPRIGHT,
    SPRITE_12_STATE_CUP_KNOCKED,
    SPRITE_12_STATE_FRAME_UPRIGHT,
    SPRITE_12_STATE_FRAME_KNOCKED,
    SPRITE_12_STATE_BONE,
    SPRITE_12_STATE_SKULL,
    SPRITE_12_STATE_BOOK,
    SPRITE_12_STATE_EMF,
    SPRITE_12_STATE_SPIRIT_BOX,
    SPRITE_12_STATE_NIGHT_VISION,
    SPRITE_12_STATE_THERMOMETER,
    SPRITE_12_STATE_CHECKED,
    SPRITE_12_STATE_LOSE,
    SPRITE_12_STATE_WIN,
    SPRITE_12_STATE_BOXO,
    SPRITE_12_STATE_BLOT,
    SPRITE_12_STATE_MARK
};

const struct spritesheet_t sprite_markers = {
    .n_metasprites = 3,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_markers_metasprites,
    .animations = sprite_markers_animations,
    .animations_lookup = sprite_markers_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_markers_tileset),
    .cgb_tileset = { NULL, NULL }
};

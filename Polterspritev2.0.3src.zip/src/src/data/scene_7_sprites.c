#pragma bank 255

// Scene: Equipment
// Sprites

#include "gbs_types.h"
#include "data/sprite_equipment.h"

BANKREF(scene_7_sprites)

const far_ptr_t scene_7_sprites[] = {
    TO_FAR_PTR_T(sprite_equipment)
};

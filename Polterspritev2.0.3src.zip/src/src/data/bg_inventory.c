#pragma bank 255

// Background: inventory

#include "gbs_types.h"
#include "data/bg_inventory_tileset.h"
#include "data/bg_inventory_tilemap.h"

BANKREF(bg_inventory)

const struct background_t bg_inventory = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_inventory_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_inventory_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

#pragma bank 255

// Background: big tent

#include "gbs_types.h"
#include "data/bg_big_tent_tileset.h"
#include "data/bg_big_tent_tilemap.h"

BANKREF(bg_big_tent)

const struct background_t bg_big_tent = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_big_tent_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_big_tent_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

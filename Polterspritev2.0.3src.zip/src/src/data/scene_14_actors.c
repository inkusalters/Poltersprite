#pragma bank 255

// Scene: Food Stands
// Actors

#include "gbs_types.h"
#include "data/sprite_ghost1.h"
#include "data/actor_44_update.h"
#include "data/actor_44_interact.h"
#include "data/sprite_button_prompts.h"
#include "data/actor_53_update.h"
#include "data/sprite_bones.h"
#include "data/actor_55_interact.h"
#include "data/sprite_equipmentv2.h"
#include "data/sprite_equipmentv2.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_boxo.h"

BANKREF(scene_14_actors)

const struct actor_t scene_14_actors[] = {
    {
        // FoodGhost,
        .pos = {
            .x = 72 * 16,
            .y = 64 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_ghost1),
        .move_speed = 16,
        .anim_tick = 7,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_44_update),
        .script = TO_FAR_PTR_T(actor_44_interact),
        .reserve_tiles = 36
    },
    {
        // Actor 2,
        .pos = {
            .x = 136 * 16,
            .y = 136 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_button_prompts),
        .move_speed = 16,
        .anim_tick = 255,
        .pinned = TRUE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = FALSE,
        .script_update = TO_FAR_PTR_T(actor_53_update),
        .reserve_tiles = 0
    },
    {
        // Bone,
        .pos = {
            .x = 24 * 16,
            .y = 96 * 16
        },
        .bounds = {
            .left = 8,
            .bottom = 7,
            .right = 15,
            .top = 0
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bones),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(actor_55_interact),
        .reserve_tiles = 0
    },
    {
        // ActiveItem,
        .pos = {
            .x = 8 * 16,
            .y = 136 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_equipmentv2),
        .move_speed = 16,
        .anim_tick = 255,
        .pinned = TRUE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = FALSE,
        .reserve_tiles = 0
    },
    {
        // InactiveItem,
        .pos = {
            .x = 24 * 16,
            .y = 136 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_equipmentv2),
        .move_speed = 16,
        .anim_tick = 255,
        .pinned = TRUE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = FALSE,
        .reserve_tiles = 0
    },
    {
        // Actor 6,
        .pos = {
            .x = 128 * 16,
            .y = 120 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_ghost_events),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .reserve_tiles = 0
    },
    {
        // Actor 7,
        .pos = {
            .x = 120 * 16,
            .y = 32 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_boxo),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .reserve_tiles = 0
    }
};

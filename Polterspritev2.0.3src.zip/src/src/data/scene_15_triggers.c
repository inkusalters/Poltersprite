#pragma bank 255

// Scene: Carnival Games
// Triggers

#include "gbs_types.h"
#include "data/trigger_52_interact.h"
#include "data/trigger_53_interact.h"
#include "data/trigger_54_interact.h"
#include "data/trigger_66_interact.h"
#include "data/trigger_67_interact.h"
#include "data/trigger_68_interact.h"
#include "data/trigger_74_interact.h"
#include "data/trigger_75_interact.h"

BANKREF(scene_15_triggers)

const struct trigger_t scene_15_triggers[] = {
    {
        // Trigger 1,
        .x = 7,
        .y = 0,
        .width = 4,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_52_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 0,
        .y = 6,
        .width = 1,
        .height = 6,
        .script = TO_FAR_PTR_T(trigger_53_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 19,
        .y = 6,
        .width = 1,
        .height = 6,
        .script = TO_FAR_PTR_T(trigger_54_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 14,
        .y = 14,
        .width = 2,
        .height = 3,
        .script = TO_FAR_PTR_T(trigger_66_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 5,
        .x = 9,
        .y = 14,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_67_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 6,
        .x = 3,
        .y = 1,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_68_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 7,
        .x = 14,
        .y = 2,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_74_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 8,
        .x = 6,
        .y = 13,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_75_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

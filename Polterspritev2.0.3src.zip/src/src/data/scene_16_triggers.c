#pragma bank 255

// Scene: Graveyard
// Triggers

#include "gbs_types.h"
#include "data/trigger_47_interact.h"
#include "data/trigger_50_interact.h"
#include "data/trigger_51_interact.h"
#include "data/trigger_72_interact.h"
#include "data/trigger_73_interact.h"

BANKREF(scene_16_triggers)

const struct trigger_t scene_16_triggers[] = {
    {
        // Trigger 1,
        .x = 16,
        .y = 13,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_47_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 2,
        .x = 0,
        .y = 8,
        .width = 1,
        .height = 4,
        .script = TO_FAR_PTR_T(trigger_50_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 10,
        .y = 17,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_51_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 12,
        .y = 7,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_72_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 5,
        .x = 5,
        .y = 13,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_73_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

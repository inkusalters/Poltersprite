#pragma bank 255

// Background: food stands

#include "gbs_types.h"
#include "data/bg_food_stands_tileset.h"
#include "data/bg_food_stands_tilemap.h"

BANKREF(bg_food_stands)

const struct background_t bg_food_stands = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_food_stands_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_food_stands_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

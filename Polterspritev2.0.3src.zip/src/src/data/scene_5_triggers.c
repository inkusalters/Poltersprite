#pragma bank 255

// Scene: Bedroom
// Triggers

#include "gbs_types.h"
#include "data/trigger_7_interact.h"
#include "data/trigger_10_interact.h"
#include "data/trigger_11_interact.h"
#include "data/trigger_16_interact.h"
#include "data/trigger_18_interact.h"
#include "data/trigger_37_interact.h"

BANKREF(scene_5_triggers)

const struct trigger_t scene_5_triggers[] = {
    {
        // Trigger 1,
        .x = 5,
        .y = 16,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_7_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 13,
        .y = 5,
        .width = 3,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_10_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 6,
        .y = 6,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_11_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 4,
        .x = 3,
        .y = 3,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_16_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 5,
        .x = 3,
        .y = 8,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_18_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 6,
        .x = 14,
        .y = 12,
        .width = 3,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_37_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

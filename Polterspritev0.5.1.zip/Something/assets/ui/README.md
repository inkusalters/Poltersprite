Place .png files in this folder to use them as UI elements of your game

Docs: https://www.gbstudio.dev/docs/assets/ui-elements

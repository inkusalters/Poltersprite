#ifndef SCENE_14_INIT_H
#define SCENE_14_INIT_H

// Script scene_14_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_14_init)
extern const unsigned char scene_14_init[];

#endif

#ifndef SCRIPT_INPUT_5_H
#define SCRIPT_INPUT_5_H

// Script script_input_5

#include "gbs_types.h"

BANKREF_EXTERN(script_input_5)
extern const unsigned char script_input_5[];

#endif

#ifndef SPRITE_CHECKBOXES_H
#define SPRITE_CHECKBOXES_H

// SpriteSheet: checkboxes

#include "gbs_types.h"

BANKREF_EXTERN(sprite_checkboxes)
extern const struct spritesheet_t sprite_checkboxes;

#endif

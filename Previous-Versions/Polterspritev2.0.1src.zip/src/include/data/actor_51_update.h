#ifndef ACTOR_51_UPDATE_H
#define ACTOR_51_UPDATE_H

// Script actor_51_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_51_update)
extern const unsigned char actor_51_update[];

#endif

#ifndef TRIGGER_47_INTERACT_H
#define TRIGGER_47_INTERACT_H

// Script trigger_47_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_47_interact)
extern const unsigned char trigger_47_interact[];

#endif

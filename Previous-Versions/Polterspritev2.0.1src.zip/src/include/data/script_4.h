#ifndef SCRIPT_4_H
#define SCRIPT_4_H

// Script script_4

#include "gbs_types.h"

BANKREF_EXTERN(script_4)
extern const unsigned char script_4[];

#endif

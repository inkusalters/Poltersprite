#ifndef ACTOR_18_INTERACT_H
#define ACTOR_18_INTERACT_H

// Script actor_18_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_18_interact)
extern const unsigned char actor_18_interact[];

#endif

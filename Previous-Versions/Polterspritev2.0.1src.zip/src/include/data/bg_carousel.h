#ifndef BG_CAROUSEL_H
#define BG_CAROUSEL_H

// Background: carousel

#include "gbs_types.h"

BANKREF_EXTERN(bg_carousel)
extern const struct background_t bg_carousel;

#endif

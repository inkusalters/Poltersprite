#ifndef SCENE_5_TRIGGERS_H
#define SCENE_5_TRIGGERS_H

// Scene: Bedroom
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_5_triggers)
extern const struct trigger_t scene_5_triggers[];

#endif

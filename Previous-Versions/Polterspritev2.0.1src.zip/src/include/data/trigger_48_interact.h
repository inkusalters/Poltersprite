#ifndef TRIGGER_48_INTERACT_H
#define TRIGGER_48_INTERACT_H

// Script trigger_48_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_48_interact)
extern const unsigned char trigger_48_interact[];

#endif

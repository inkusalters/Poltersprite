#ifndef SCRIPT_1_H
#define SCRIPT_1_H

// Script script_1

#include "gbs_types.h"

BANKREF_EXTERN(script_1)
extern const unsigned char script_1[];

#endif

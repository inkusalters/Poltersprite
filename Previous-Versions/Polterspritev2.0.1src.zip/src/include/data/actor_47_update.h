#ifndef ACTOR_47_UPDATE_H
#define ACTOR_47_UPDATE_H

// Script actor_47_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_47_update)
extern const unsigned char actor_47_update[];

#endif

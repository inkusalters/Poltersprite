#ifndef BG_PATH_TILEMAP_H
#define BG_PATH_TILEMAP_H

// Tilemap bg_path_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_path_tilemap)
extern const unsigned char bg_path_tilemap[];

#endif

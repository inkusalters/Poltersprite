#ifndef SCENE_13_ACTORS_H
#define SCENE_13_ACTORS_H

// Scene: Path
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_13_actors)
extern const struct actor_t scene_13_actors[];

#endif

#pragma bank 255

// Scene: Carousel
// Triggers

#include "gbs_types.h"
#include "data/trigger_55_interact.h"
#include "data/trigger_65_interact.h"
#include "data/trigger_76_interact.h"

BANKREF(scene_19_triggers)

const struct trigger_t scene_19_triggers[] = {
    {
        // Trigger 1,
        .x = 0,
        .y = 6,
        .width = 1,
        .height = 4,
        .script = TO_FAR_PTR_T(trigger_55_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 14,
        .y = 12,
        .width = 2,
        .height = 3,
        .script = TO_FAR_PTR_T(trigger_65_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 9,
        .y = 4,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_76_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

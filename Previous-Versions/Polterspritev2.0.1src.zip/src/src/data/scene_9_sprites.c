#pragma bank 255

// Scene: Truck
// Sprites

#include "gbs_types.h"
#include "data/sprite_equipmentv2.h"
#include "data/sprite_button_prompts.h"

BANKREF(scene_9_sprites)

const far_ptr_t scene_9_sprites[] = {
    TO_FAR_PTR_T(sprite_equipmentv2),
    TO_FAR_PTR_T(sprite_button_prompts)
};

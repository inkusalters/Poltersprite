#pragma bank 255

// Scene: Entrance
// Sprites

#include "gbs_types.h"
#include "data/sprite_button_prompts.h"
#include "data/sprite_bones.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_equipmentv2.h"
#include "data/sprite_boxo.h"

BANKREF(scene_12_sprites)

const far_ptr_t scene_12_sprites[] = {
    TO_FAR_PTR_T(sprite_button_prompts),
    TO_FAR_PTR_T(sprite_bones),
    TO_FAR_PTR_T(sprite_ghost_events),
    TO_FAR_PTR_T(sprite_equipmentv2),
    TO_FAR_PTR_T(sprite_boxo)
};

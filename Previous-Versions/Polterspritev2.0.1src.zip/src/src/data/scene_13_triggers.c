#pragma bank 255

// Scene: Path
// Triggers

#include "gbs_types.h"
#include "data/trigger_48_interact.h"
#include "data/trigger_49_interact.h"
#include "data/trigger_58_interact.h"
#include "data/trigger_59_interact.h"
#include "data/trigger_61_interact.h"

BANKREF(scene_13_triggers)

const struct trigger_t scene_13_triggers[] = {
    {
        // Trigger 1,
        .x = 6,
        .y = 17,
        .width = 8,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_48_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 19,
        .y = 8,
        .width = 1,
        .height = 4,
        .script = TO_FAR_PTR_T(trigger_49_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 0,
        .y = 6,
        .width = 1,
        .height = 6,
        .script = TO_FAR_PTR_T(trigger_58_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 8,
        .y = 5,
        .width = 4,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_59_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 5,
        .x = 16,
        .y = 7,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_61_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

#pragma bank 255
// SpriteSheet: spritesheet

#include "gbs_types.h"
#include "data/sprite_spritesheet_1__tileset.h"


BANKREF(sprite_spritesheet_1_)

#define SPRITE_4_STATE_DEFAULT 0
#define SPRITE_4_STATE_A_BUTTON 0
#define SPRITE_4_STATE_B_BUTTON 0
#define SPRITE_4_STATE_HANDPRINT 0
#define SPRITE_4_STATE_CUP_UPRIGHT 0
#define SPRITE_4_STATE_CUP_KNOCKED 0
#define SPRITE_4_STATE_FRAME_UPRIGHT 0
#define SPRITE_4_STATE_FRAME_KNOCKED 0
#define SPRITE_4_STATE_BONE 0
#define SPRITE_4_STATE_SKULL 0
#define SPRITE_4_STATE_BOOK 0
#define SPRITE_4_STATE_EMF 0
#define SPRITE_4_STATE_SPIRIT_BOX 0
#define SPRITE_4_STATE_NIGHT_VISION 0
#define SPRITE_4_STATE_THERMOMETER 0
#define SPRITE_4_STATE_CHECKED 0
#define SPRITE_4_STATE_LOSE 0
#define SPRITE_4_STATE_WIN 0
#define SPRITE_4_STATE_BOXO 0
#define SPRITE_4_STATE_BLOT 0
#define SPRITE_4_STATE_MARK 0

const metasprite_t sprite_spritesheet_1__metasprite_0[]  = {
    { 0, 8, 8, 0 }, { 0, -8, 10, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_1[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_2[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_3[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_4[]  = {
    { 0, 8, 28, 0 }, { 0, -8, 30, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_5[]  = {
    { 0, 8, 32, 0 }, { 0, -8, 34, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_6[]  = {
    { 0, 8, 12, 0 }, { 0, -8, 14, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_7[]  = {
    { 0, 8, 16, 0 }, { 0, -8, 18, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_8[]  = {
    { 0, 8, 20, 0 }, { 0, -8, 22, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_9[]  = {
    { 0, 8, 24, 0 }, { 0, -8, 26, 0 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_10[]  = {
    { 0, 0, 12, 32 }, { 0, 8, 14, 32 },
    {metasprite_end}
};

const metasprite_t sprite_spritesheet_1__metasprite_11[]  = {
    { 0, 0, 16, 32 }, { 0, 8, 18, 32 },
    {metasprite_end}
};

const metasprite_t * const sprite_spritesheet_1__metasprites[] = {
    sprite_spritesheet_1__metasprite_0,
    sprite_spritesheet_1__metasprite_1,
    sprite_spritesheet_1__metasprite_2,
    sprite_spritesheet_1__metasprite_3,
    sprite_spritesheet_1__metasprite_4,
    sprite_spritesheet_1__metasprite_5,
    sprite_spritesheet_1__metasprite_6,
    sprite_spritesheet_1__metasprite_1,
    sprite_spritesheet_1__metasprite_7,
    sprite_spritesheet_1__metasprite_1,
    sprite_spritesheet_1__metasprite_8,
    sprite_spritesheet_1__metasprite_2,
    sprite_spritesheet_1__metasprite_9,
    sprite_spritesheet_1__metasprite_2,
    sprite_spritesheet_1__metasprite_10,
    sprite_spritesheet_1__metasprite_3,
    sprite_spritesheet_1__metasprite_11,
    sprite_spritesheet_1__metasprite_3
};

const struct animation_t sprite_spritesheet_1__animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 3,
        .end = 3
    },
    {
        .start = 4,
        .end = 5
    },
    {
        .start = 6,
        .end = 9
    },
    {
        .start = 10,
        .end = 13
    },
    {
        .start = 14,
        .end = 17
    }
};

const UWORD sprite_spritesheet_1__animations_lookup[] = {
    SPRITE_4_STATE_DEFAULT
};

const struct spritesheet_t sprite_spritesheet_1_ = {
    .n_metasprites = 18,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_spritesheet_1__metasprites,
    .animations = sprite_spritesheet_1__animations,
    .animations_lookup = sprite_spritesheet_1__animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_spritesheet_1__tileset),
    .cgb_tileset = { NULL, NULL }
};

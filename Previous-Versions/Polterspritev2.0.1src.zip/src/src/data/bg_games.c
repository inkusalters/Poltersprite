#pragma bank 255

// Background: games

#include "gbs_types.h"
#include "data/bg_games_tileset.h"
#include "data/bg_games_tilemap.h"

BANKREF(bg_games)

const struct background_t bg_games = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_games_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_games_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

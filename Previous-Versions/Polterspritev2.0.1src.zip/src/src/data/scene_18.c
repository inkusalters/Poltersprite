#pragma bank 255

// Scene: Big Tent

#include "gbs_types.h"
#include "data/bg_big_tent.h"
#include "data/scene_18_collisions.h"
#include "data/palette_0.h"
#include "data/palette_1.h"
#include "data/sprite_spritesheet_1_.h"
#include "data/scene_18_actors.h"
#include "data/scene_18_triggers.h"
#include "data/scene_18_sprites.h"
#include "data/scene_18_init.h"

BANKREF(scene_18)

const struct scene_t scene_18 = {
    .width = 20,
    .height = 18,
    .type = SCENE_TYPE_TOPDOWN,
    .background = TO_FAR_PTR_T(bg_big_tent),
    .collisions = TO_FAR_PTR_T(scene_18_collisions),
    .parallax_rows = {
        PARALLAX_STEP(0,0,0)
    },
    .palette = TO_FAR_PTR_T(palette_0),
    .sprite_palette = TO_FAR_PTR_T(palette_1),
    .reserve_tiles = 0,
    .player_sprite = TO_FAR_PTR_T(sprite_spritesheet_1_),
    .n_actors = 7,
    .n_triggers = 4,
    .n_sprites = 5,
    .n_projectiles = 0,
    .actors = TO_FAR_PTR_T(scene_18_actors),
    .triggers = TO_FAR_PTR_T(scene_18_triggers),
    .sprites = TO_FAR_PTR_T(scene_18_sprites),
    .script_init = TO_FAR_PTR_T(scene_18_init)
};

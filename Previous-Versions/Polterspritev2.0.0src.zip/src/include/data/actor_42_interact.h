#ifndef ACTOR_42_INTERACT_H
#define ACTOR_42_INTERACT_H

// Script actor_42_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_42_interact)
extern const unsigned char actor_42_interact[];

#endif

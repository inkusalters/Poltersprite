#ifndef TRIGGER_37_INTERACT_H
#define TRIGGER_37_INTERACT_H

// Script trigger_37_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_37_interact)
extern const unsigned char trigger_37_interact[];

#endif

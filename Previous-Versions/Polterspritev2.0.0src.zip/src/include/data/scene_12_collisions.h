#ifndef SCENE_12_COLLISIONS_H
#define SCENE_12_COLLISIONS_H

// Scene: Entrance
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_12_collisions)
extern const unsigned char scene_12_collisions[];

#endif

#ifndef SPRITE_GHOST2_TILESET_H
#define SPRITE_GHOST2_TILESET_H

// Tileset: sprite_ghost2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ghost2_tileset)
extern const struct tileset_t sprite_ghost2_tileset;

#endif

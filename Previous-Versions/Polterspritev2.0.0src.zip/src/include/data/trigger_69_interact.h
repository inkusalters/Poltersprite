#ifndef TRIGGER_69_INTERACT_H
#define TRIGGER_69_INTERACT_H

// Script trigger_69_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_69_interact)
extern const unsigned char trigger_69_interact[];

#endif

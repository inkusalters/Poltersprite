#ifndef SPRITE_BONES_H
#define SPRITE_BONES_H

// SpriteSheet: bones

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bones)
extern const struct spritesheet_t sprite_bones;

#endif

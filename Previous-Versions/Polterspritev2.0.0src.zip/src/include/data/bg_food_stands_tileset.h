#ifndef BG_FOOD_STANDS_TILESET_H
#define BG_FOOD_STANDS_TILESET_H

// Tileset: bg_food_stands_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_food_stands_tileset)
extern const struct tileset_t bg_food_stands_tileset;

#endif

#ifndef SPRITE_END_TEXT_H
#define SPRITE_END_TEXT_H

// SpriteSheet: end-text

#include "gbs_types.h"

BANKREF_EXTERN(sprite_end_text)
extern const struct spritesheet_t sprite_end_text;

#endif

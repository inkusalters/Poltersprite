#ifndef SPRITE_BOXO_TILESET_H
#define SPRITE_BOXO_TILESET_H

// Tileset: sprite_boxo_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_boxo_tileset)
extern const struct tileset_t sprite_boxo_tileset;

#endif

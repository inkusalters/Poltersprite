#ifndef BG_GRAVEYARD_TILEMAP_H
#define BG_GRAVEYARD_TILEMAP_H

// Tilemap bg_graveyard_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_graveyard_tilemap)
extern const unsigned char bg_graveyard_tilemap[];

#endif

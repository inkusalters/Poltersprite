#ifndef TRIGGER_59_INTERACT_H
#define TRIGGER_59_INTERACT_H

// Script trigger_59_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_59_interact)
extern const unsigned char trigger_59_interact[];

#endif

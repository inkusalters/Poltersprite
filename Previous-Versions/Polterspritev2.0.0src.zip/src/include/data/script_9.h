#ifndef SCRIPT_9_H
#define SCRIPT_9_H

// Script script_9

#include "gbs_types.h"

BANKREF_EXTERN(script_9)
extern const unsigned char script_9[];

#endif

#ifndef BG_NOTEBOOK_TILEMAP_H
#define BG_NOTEBOOK_TILEMAP_H

// Tilemap bg_notebook_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_notebook_tilemap)
extern const unsigned char bg_notebook_tilemap[];

#endif

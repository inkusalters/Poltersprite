#ifndef BG_GRAVEYARD_TILESET_H
#define BG_GRAVEYARD_TILESET_H

// Tileset: bg_graveyard_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_graveyard_tileset)
extern const struct tileset_t bg_graveyard_tileset;

#endif

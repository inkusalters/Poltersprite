#ifndef BG_BATHROOM_TILEMAP_H
#define BG_BATHROOM_TILEMAP_H

// Tilemap bg_bathroom_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_bathroom_tilemap)
extern const unsigned char bg_bathroom_tilemap[];

#endif

#ifndef TRIGGER_18_INTERACT_H
#define TRIGGER_18_INTERACT_H

// Script trigger_18_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_18_interact)
extern const unsigned char trigger_18_interact[];

#endif

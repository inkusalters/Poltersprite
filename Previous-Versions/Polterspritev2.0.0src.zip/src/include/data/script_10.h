#ifndef SCRIPT_10_H
#define SCRIPT_10_H

// Script script_10

#include "gbs_types.h"

BANKREF_EXTERN(script_10)
extern const unsigned char script_10[];

#endif

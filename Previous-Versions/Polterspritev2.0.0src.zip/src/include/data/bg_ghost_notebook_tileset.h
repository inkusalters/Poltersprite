#ifndef BG_GHOST_NOTEBOOK_TILESET_H
#define BG_GHOST_NOTEBOOK_TILESET_H

// Tileset: bg_ghost_notebook_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_ghost_notebook_tileset)
extern const struct tileset_t bg_ghost_notebook_tileset;

#endif

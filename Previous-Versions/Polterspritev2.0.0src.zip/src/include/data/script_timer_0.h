#ifndef SCRIPT_TIMER_0_H
#define SCRIPT_TIMER_0_H

// Script script_timer_0

#include "gbs_types.h"

BANKREF_EXTERN(script_timer_0)
extern const unsigned char script_timer_0[];

#endif

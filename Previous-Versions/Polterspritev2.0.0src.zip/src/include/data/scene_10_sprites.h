#ifndef SCENE_10_SPRITES_H
#define SCENE_10_SPRITES_H

// Scene: Notebook
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_10_sprites)
extern const far_ptr_t scene_10_sprites[];

#endif

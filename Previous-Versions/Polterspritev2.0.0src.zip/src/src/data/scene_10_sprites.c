#pragma bank 255

// Scene: Notebook
// Sprites

#include "gbs_types.h"
#include "data/sprite_checkboxes.h"

BANKREF(scene_10_sprites)

const far_ptr_t scene_10_sprites[] = {
    TO_FAR_PTR_T(sprite_checkboxes)
};

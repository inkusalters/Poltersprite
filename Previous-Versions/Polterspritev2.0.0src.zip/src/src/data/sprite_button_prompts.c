#pragma bank 255
// SpriteSheet: button-prompts

#include "gbs_types.h"
#include "data/sprite_button_prompts_tileset.h"


BANKREF(sprite_button_prompts)

#define SPRITE_5_STATE_DEFAULT 0
#define SPRITE_5_STATE_A_BUTTON 8
#define SPRITE_5_STATE_B_BUTTON 16
#define SPRITE_5_STATE_HANDPRINT 0
#define SPRITE_5_STATE_CUP_UPRIGHT 0
#define SPRITE_5_STATE_CUP_KNOCKED 0
#define SPRITE_5_STATE_FRAME_UPRIGHT 0
#define SPRITE_5_STATE_FRAME_KNOCKED 0
#define SPRITE_5_STATE_BONE 0
#define SPRITE_5_STATE_SKULL 0
#define SPRITE_5_STATE_BOOK 0
#define SPRITE_5_STATE_EMF 0
#define SPRITE_5_STATE_SPIRIT_BOX 0
#define SPRITE_5_STATE_NIGHT_VISION 0
#define SPRITE_5_STATE_THERMOMETER 0
#define SPRITE_5_STATE_CHECKED 0
#define SPRITE_5_STATE_LOSE 0
#define SPRITE_5_STATE_WIN 0
#define SPRITE_5_STATE_BOXO 0
#define SPRITE_5_STATE_BLOT 0
#define SPRITE_5_STATE_MARK 0

const metasprite_t sprite_button_prompts_metasprite_0[]  = {
    {metasprite_end}
};

const metasprite_t sprite_button_prompts_metasprite_1[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_button_prompts_metasprite_2[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t * const sprite_button_prompts_metasprites[] = {
    sprite_button_prompts_metasprite_0,
    sprite_button_prompts_metasprite_1,
    sprite_button_prompts_metasprite_2
};

const struct animation_t sprite_button_prompts_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    }
};

const UWORD sprite_button_prompts_animations_lookup[] = {
    SPRITE_5_STATE_DEFAULT,
    SPRITE_5_STATE_A_BUTTON,
    SPRITE_5_STATE_B_BUTTON
};

const struct spritesheet_t sprite_button_prompts = {
    .n_metasprites = 3,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_button_prompts_metasprites,
    .animations = sprite_button_prompts_animations,
    .animations_lookup = sprite_button_prompts_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_button_prompts_tileset),
    .cgb_tileset = { NULL, NULL }
};

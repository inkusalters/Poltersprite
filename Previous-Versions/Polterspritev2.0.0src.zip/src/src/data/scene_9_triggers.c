#pragma bank 255

// Scene: Truck
// Triggers

#include "gbs_types.h"
#include "data/trigger_9_interact.h"
#include "data/trigger_20_interact.h"
#include "data/trigger_29_interact.h"
#include "data/trigger_30_interact.h"

BANKREF(scene_9_triggers)

const struct trigger_t scene_9_triggers[] = {
    {
        // Trigger 1,
        .x = 9,
        .y = 3,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_9_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 11,
        .y = 9,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_20_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 6,
        .y = 5,
        .width = 1,
        .height = 7,
        .script = TO_FAR_PTR_T(trigger_29_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 4,
        .x = 9,
        .y = 11,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_30_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

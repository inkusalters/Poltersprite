#pragma bank 255

// Scene: Bathroom
// Triggers

#include "gbs_types.h"
#include "data/trigger_6_interact.h"
#include "data/trigger_14_interact.h"
#include "data/trigger_15_interact.h"
#include "data/trigger_36_interact.h"

BANKREF(scene_6_triggers)

const struct trigger_t scene_6_triggers[] = {
    {
        // Trigger 1,
        .x = 10,
        .y = 16,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_6_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 13,
        .y = 14,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_14_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 5,
        .y = 10,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_15_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 4,
        .x = 4,
        .y = 13,
        .width = 3,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_36_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

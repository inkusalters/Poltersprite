#pragma bank 255

// Scene: Kitchen
// Triggers

#include "gbs_types.h"
#include "data/trigger_3_interact.h"
#include "data/trigger_4_interact.h"
#include "data/trigger_17_interact.h"
#include "data/trigger_19_interact.h"
#include "data/trigger_21_interact.h"
#include "data/trigger_35_interact.h"

BANKREF(scene_4_triggers)

const struct trigger_t scene_4_triggers[] = {
    {
        // Trigger 1,
        .x = 18,
        .y = 8,
        .width = 1,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_3_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 10,
        .y = 16,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_4_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 5,
        .y = 3,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_17_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 4,
        .x = 5,
        .y = 8,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_19_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 5,
        .x = 13,
        .y = 12,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_21_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 6,
        .x = 8,
        .y = 6,
        .width = 3,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_35_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

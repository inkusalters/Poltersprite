#pragma bank 255

// Scene: Ferris Wheel
// Triggers

#include "gbs_types.h"
#include "data/trigger_56_interact.h"
#include "data/trigger_57_interact.h"
#include "data/trigger_62_interact.h"
#include "data/trigger_63_interact.h"
#include "data/trigger_64_interact.h"

BANKREF(scene_17_triggers)

const struct trigger_t scene_17_triggers[] = {
    {
        // Trigger 1,
        .x = 5,
        .y = 17,
        .width = 3,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_56_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 19,
        .y = 6,
        .width = 1,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_57_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 4,
        .y = 6,
        .width = 3,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_62_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 4,
        .x = 9,
        .y = 5,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_63_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 5,
        .x = 9,
        .y = 1,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_64_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

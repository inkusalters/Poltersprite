#pragma bank 255

// Scene: Big Tent
// Triggers

#include "gbs_types.h"
#include "data/trigger_60_interact.h"
#include "data/trigger_69_interact.h"
#include "data/trigger_70_interact.h"

BANKREF(scene_18_triggers)

const struct trigger_t scene_18_triggers[] = {
    {
        // Trigger 1,
        .x = 6,
        .y = 17,
        .width = 8,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_60_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 12,
        .y = 5,
        .width = 3,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_69_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 9,
        .y = 9,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_70_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

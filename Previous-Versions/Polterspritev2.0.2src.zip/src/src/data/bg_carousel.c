#pragma bank 255

// Background: carousel

#include "gbs_types.h"
#include "data/bg_carousel_tileset.h"
#include "data/bg_carousel_tilemap.h"

BANKREF(bg_carousel)

const struct background_t bg_carousel = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_carousel_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_carousel_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

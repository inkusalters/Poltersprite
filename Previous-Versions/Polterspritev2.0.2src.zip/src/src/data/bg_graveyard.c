#pragma bank 255

// Background: graveyard

#include "gbs_types.h"
#include "data/bg_graveyard_tileset.h"
#include "data/bg_graveyard_tilemap.h"

BANKREF(bg_graveyard)

const struct background_t bg_graveyard = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_graveyard_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_graveyard_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

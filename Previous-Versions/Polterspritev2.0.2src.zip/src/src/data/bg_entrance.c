#pragma bank 255

// Background: entrance

#include "gbs_types.h"
#include "data/bg_entrance_tileset.h"
#include "data/bg_entrance_tilemap.h"

BANKREF(bg_entrance)

const struct background_t bg_entrance = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_entrance_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_entrance_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

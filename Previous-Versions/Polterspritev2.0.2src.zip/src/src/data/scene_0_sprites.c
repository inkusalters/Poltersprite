#pragma bank 255

// Scene: Ghosts
// Sprites

#include "gbs_types.h"
#include "data/sprite_markers.h"

BANKREF(scene_0_sprites)

const far_ptr_t scene_0_sprites[] = {
    TO_FAR_PTR_T(sprite_markers)
};

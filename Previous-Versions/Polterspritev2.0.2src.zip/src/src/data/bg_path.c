#pragma bank 255

// Background: path

#include "gbs_types.h"
#include "data/bg_path_tileset.h"
#include "data/bg_path_tilemap.h"

BANKREF(bg_path)

const struct background_t bg_path = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_path_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_path_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

#pragma bank 255

// Scene: Garage
// Sprites

#include "gbs_types.h"
#include "data/sprite_button_prompts.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_bones.h"
#include "data/sprite_equipmentv2.h"

BANKREF(scene_8_sprites)

const far_ptr_t scene_8_sprites[] = {
    TO_FAR_PTR_T(sprite_button_prompts),
    TO_FAR_PTR_T(sprite_ghost_events),
    TO_FAR_PTR_T(sprite_bones),
    TO_FAR_PTR_T(sprite_equipmentv2)
};

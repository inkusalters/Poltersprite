#pragma bank 255

// Scene: Food Stands
// Triggers

#include "gbs_types.h"
#include "data/trigger_32_interact.h"
#include "data/trigger_31_interact.h"
#include "data/trigger_38_interact.h"
#include "data/trigger_39_interact.h"
#include "data/trigger_41_interact.h"
#include "data/trigger_45_interact.h"
#include "data/trigger_46_interact.h"

BANKREF(scene_14_triggers)

const struct trigger_t scene_14_triggers[] = {
    {
        // Trigger 1,
        .x = 16,
        .y = 13,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_32_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 2,
        .x = 14,
        .y = 14,
        .width = 1,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_31_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 19,
        .y = 7,
        .width = 1,
        .height = 5,
        .script = TO_FAR_PTR_T(trigger_38_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 3,
        .y = 11,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_39_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 5,
        .x = 1,
        .y = 0,
        .width = 6,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_41_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 6,
        .x = 10,
        .y = 6,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_45_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 7,
        .x = 15,
        .y = 6,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_46_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

#pragma bank 255
// SpriteSheet: boxo

#include "gbs_types.h"
#include "data/sprite_boxo_tileset.h"


BANKREF(sprite_boxo)

#define SPRITE_11_STATE_DEFAULT 0
#define SPRITE_11_STATE_A_BUTTON 0
#define SPRITE_11_STATE_B_BUTTON 0
#define SPRITE_11_STATE_HANDPRINT 0
#define SPRITE_11_STATE_CUP_UPRIGHT 0
#define SPRITE_11_STATE_CUP_KNOCKED 0
#define SPRITE_11_STATE_FRAME_UPRIGHT 0
#define SPRITE_11_STATE_FRAME_KNOCKED 0
#define SPRITE_11_STATE_BONE 0
#define SPRITE_11_STATE_SKULL 0
#define SPRITE_11_STATE_BOOK 0
#define SPRITE_11_STATE_EMF 0
#define SPRITE_11_STATE_SPIRIT_BOX 0
#define SPRITE_11_STATE_NIGHT_VISION 0
#define SPRITE_11_STATE_THERMOMETER 0
#define SPRITE_11_STATE_CHECKED 0
#define SPRITE_11_STATE_LOSE 0
#define SPRITE_11_STATE_WIN 0
#define SPRITE_11_STATE_BOXO 8
#define SPRITE_11_STATE_BLOT 0
#define SPRITE_11_STATE_MARK 0

const metasprite_t sprite_boxo_metasprite_0[]  = {
    {metasprite_end}
};

const metasprite_t sprite_boxo_metasprite_1[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t * const sprite_boxo_metasprites[] = {
    sprite_boxo_metasprite_0,
    sprite_boxo_metasprite_1
};

const struct animation_t sprite_boxo_animations[] = {
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    }
};

const UWORD sprite_boxo_animations_lookup[] = {
    SPRITE_11_STATE_DEFAULT,
    SPRITE_11_STATE_A_BUTTON,
    SPRITE_11_STATE_B_BUTTON,
    SPRITE_11_STATE_HANDPRINT,
    SPRITE_11_STATE_CUP_UPRIGHT,
    SPRITE_11_STATE_CUP_KNOCKED,
    SPRITE_11_STATE_FRAME_UPRIGHT,
    SPRITE_11_STATE_FRAME_KNOCKED,
    SPRITE_11_STATE_BONE,
    SPRITE_11_STATE_SKULL,
    SPRITE_11_STATE_BOOK,
    SPRITE_11_STATE_EMF,
    SPRITE_11_STATE_SPIRIT_BOX,
    SPRITE_11_STATE_NIGHT_VISION,
    SPRITE_11_STATE_THERMOMETER,
    SPRITE_11_STATE_CHECKED,
    SPRITE_11_STATE_LOSE,
    SPRITE_11_STATE_WIN,
    SPRITE_11_STATE_BOXO
};

const struct spritesheet_t sprite_boxo = {
    .n_metasprites = 2,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_boxo_metasprites,
    .animations = sprite_boxo_animations,
    .animations_lookup = sprite_boxo_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_boxo_tileset),
    .cgb_tileset = { NULL, NULL }
};

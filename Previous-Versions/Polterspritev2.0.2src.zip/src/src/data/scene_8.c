#pragma bank 255

// Scene: Garage

#include "gbs_types.h"
#include "data/bg_garage.h"
#include "data/scene_8_collisions.h"
#include "data/palette_0.h"
#include "data/palette_1.h"
#include "data/sprite_spritesheet_1_.h"
#include "data/scene_8_actors.h"
#include "data/scene_8_triggers.h"
#include "data/scene_8_sprites.h"
#include "data/scene_8_init.h"

BANKREF(scene_8)

const struct scene_t scene_8 = {
    .width = 20,
    .height = 18,
    .type = SCENE_TYPE_TOPDOWN,
    .background = TO_FAR_PTR_T(bg_garage),
    .collisions = TO_FAR_PTR_T(scene_8_collisions),
    .parallax_rows = {
        PARALLAX_STEP(0,0,0)
    },
    .palette = TO_FAR_PTR_T(palette_0),
    .sprite_palette = TO_FAR_PTR_T(palette_1),
    .reserve_tiles = 0,
    .player_sprite = TO_FAR_PTR_T(sprite_spritesheet_1_),
    .n_actors = 7,
    .n_triggers = 5,
    .n_sprites = 4,
    .n_projectiles = 0,
    .actors = TO_FAR_PTR_T(scene_8_actors),
    .triggers = TO_FAR_PTR_T(scene_8_triggers),
    .sprites = TO_FAR_PTR_T(scene_8_sprites),
    .script_init = TO_FAR_PTR_T(scene_8_init)
};

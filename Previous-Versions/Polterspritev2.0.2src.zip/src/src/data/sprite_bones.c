#pragma bank 255
// SpriteSheet: bones

#include "gbs_types.h"
#include "data/sprite_bones_tileset.h"


BANKREF(sprite_bones)

#define SPRITE_7_STATE_DEFAULT 0
#define SPRITE_7_STATE_A_BUTTON 0
#define SPRITE_7_STATE_B_BUTTON 0
#define SPRITE_7_STATE_HANDPRINT 0
#define SPRITE_7_STATE_CUP_UPRIGHT 0
#define SPRITE_7_STATE_CUP_KNOCKED 0
#define SPRITE_7_STATE_FRAME_UPRIGHT 0
#define SPRITE_7_STATE_FRAME_KNOCKED 0
#define SPRITE_7_STATE_BONE 8
#define SPRITE_7_STATE_SKULL 16
#define SPRITE_7_STATE_BOOK 0
#define SPRITE_7_STATE_EMF 0
#define SPRITE_7_STATE_SPIRIT_BOX 0
#define SPRITE_7_STATE_NIGHT_VISION 0
#define SPRITE_7_STATE_THERMOMETER 0
#define SPRITE_7_STATE_CHECKED 0
#define SPRITE_7_STATE_LOSE 0
#define SPRITE_7_STATE_WIN 0
#define SPRITE_7_STATE_BOXO 0
#define SPRITE_7_STATE_BLOT 0
#define SPRITE_7_STATE_MARK 0

const metasprite_t sprite_bones_metasprite_0[]  = {
    {metasprite_end}
};

const metasprite_t sprite_bones_metasprite_1[]  = {
    { 0, 8, 0, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bones_metasprite_2[]  = {
    { 0, 8, 2, 0 },
    {metasprite_end}
};

const metasprite_t * const sprite_bones_metasprites[] = {
    sprite_bones_metasprite_0,
    sprite_bones_metasprite_1,
    sprite_bones_metasprite_2
};

const struct animation_t sprite_bones_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    }
};

const UWORD sprite_bones_animations_lookup[] = {
    SPRITE_7_STATE_DEFAULT,
    SPRITE_7_STATE_A_BUTTON,
    SPRITE_7_STATE_B_BUTTON,
    SPRITE_7_STATE_HANDPRINT,
    SPRITE_7_STATE_CUP_UPRIGHT,
    SPRITE_7_STATE_CUP_KNOCKED,
    SPRITE_7_STATE_FRAME_UPRIGHT,
    SPRITE_7_STATE_FRAME_KNOCKED,
    SPRITE_7_STATE_BONE,
    SPRITE_7_STATE_SKULL
};

const struct spritesheet_t sprite_bones = {
    .n_metasprites = 3,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_bones_metasprites,
    .animations = sprite_bones_animations,
    .animations_lookup = sprite_bones_animations_lookup,
    .bounds = {
        .left = 8,
        .bottom = 7,
        .right = 15,
        .top = 0
    },
    .tileset = TO_FAR_PTR_T(sprite_bones_tileset),
    .cgb_tileset = { NULL, NULL }
};

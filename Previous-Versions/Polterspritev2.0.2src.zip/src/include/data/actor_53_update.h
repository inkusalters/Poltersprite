#ifndef ACTOR_53_UPDATE_H
#define ACTOR_53_UPDATE_H

// Script actor_53_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_53_update)
extern const unsigned char actor_53_update[];

#endif

#ifndef BG_BIG_TENT_TILEMAP_H
#define BG_BIG_TENT_TILEMAP_H

// Tilemap bg_big_tent_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_big_tent_tilemap)
extern const unsigned char bg_big_tent_tilemap[];

#endif

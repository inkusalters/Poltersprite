#ifndef BG_ENTRANCE_H
#define BG_ENTRANCE_H

// Background: entrance

#include "gbs_types.h"

BANKREF_EXTERN(bg_entrance)
extern const struct background_t bg_entrance;

#endif

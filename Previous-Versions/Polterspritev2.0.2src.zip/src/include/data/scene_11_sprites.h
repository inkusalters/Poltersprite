#ifndef SCENE_11_SPRITES_H
#define SCENE_11_SPRITES_H

// Scene: Game Over
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_11_sprites)
extern const far_ptr_t scene_11_sprites[];

#endif

#ifndef ACTOR_57_INTERACT_H
#define ACTOR_57_INTERACT_H

// Script actor_57_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_57_interact)
extern const unsigned char actor_57_interact[];

#endif

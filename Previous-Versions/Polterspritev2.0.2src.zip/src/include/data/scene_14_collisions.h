#ifndef SCENE_14_COLLISIONS_H
#define SCENE_14_COLLISIONS_H

// Scene: Food Stands
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_14_collisions)
extern const unsigned char scene_14_collisions[];

#endif

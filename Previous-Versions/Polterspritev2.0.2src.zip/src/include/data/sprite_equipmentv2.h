#ifndef SPRITE_EQUIPMENTV2_H
#define SPRITE_EQUIPMENTV2_H

// SpriteSheet: equipmentv2

#include "gbs_types.h"

BANKREF_EXTERN(sprite_equipmentv2)
extern const struct spritesheet_t sprite_equipmentv2;

#endif

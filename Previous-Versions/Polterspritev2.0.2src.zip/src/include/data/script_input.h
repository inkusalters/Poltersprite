#ifndef SCRIPT_INPUT_H
#define SCRIPT_INPUT_H

// Script script_input

#include "gbs_types.h"

BANKREF_EXTERN(script_input)
extern const unsigned char script_input[];

#endif

#ifndef BG_TITLE_TILESET_H
#define BG_TITLE_TILESET_H

// Tileset: bg_title_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_title_tileset)
extern const struct tileset_t bg_title_tileset;

#endif

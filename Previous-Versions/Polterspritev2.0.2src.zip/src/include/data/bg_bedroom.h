#ifndef BG_BEDROOM_H
#define BG_BEDROOM_H

// Background: bedroom

#include "gbs_types.h"

BANKREF_EXTERN(bg_bedroom)
extern const struct background_t bg_bedroom;

#endif

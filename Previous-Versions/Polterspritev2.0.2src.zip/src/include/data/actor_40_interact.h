#ifndef ACTOR_40_INTERACT_H
#define ACTOR_40_INTERACT_H

// Script actor_40_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_40_interact)
extern const unsigned char actor_40_interact[];

#endif

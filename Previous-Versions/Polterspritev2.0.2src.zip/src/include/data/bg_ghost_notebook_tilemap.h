#ifndef BG_GHOST_NOTEBOOK_TILEMAP_H
#define BG_GHOST_NOTEBOOK_TILEMAP_H

// Tilemap bg_ghost_notebook_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_ghost_notebook_tilemap)
extern const unsigned char bg_ghost_notebook_tilemap[];

#endif

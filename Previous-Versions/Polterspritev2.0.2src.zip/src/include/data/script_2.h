#ifndef SCRIPT_2_H
#define SCRIPT_2_H

// Script script_2

#include "gbs_types.h"

BANKREF_EXTERN(script_2)
extern const unsigned char script_2[];

#endif

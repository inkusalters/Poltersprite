#ifndef BG_ENDSCREEN_TILEMAP_H
#define BG_ENDSCREEN_TILEMAP_H

// Tilemap bg_endscreen_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_endscreen_tilemap)
extern const unsigned char bg_endscreen_tilemap[];

#endif

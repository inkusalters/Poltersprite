#ifndef ACTOR_46_UPDATE_H
#define ACTOR_46_UPDATE_H

// Script actor_46_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_46_update)
extern const unsigned char actor_46_update[];

#endif

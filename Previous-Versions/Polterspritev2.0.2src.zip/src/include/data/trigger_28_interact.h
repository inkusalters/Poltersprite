#ifndef TRIGGER_28_INTERACT_H
#define TRIGGER_28_INTERACT_H

// Script trigger_28_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_28_interact)
extern const unsigned char trigger_28_interact[];

#endif

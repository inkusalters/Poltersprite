#ifndef SPRITE_POINTER_H
#define SPRITE_POINTER_H

// SpriteSheet: pointer

#include "gbs_types.h"

BANKREF_EXTERN(sprite_pointer)
extern const struct spritesheet_t sprite_pointer;

#endif

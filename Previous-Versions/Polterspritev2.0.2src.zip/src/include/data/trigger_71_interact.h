#ifndef TRIGGER_71_INTERACT_H
#define TRIGGER_71_INTERACT_H

// Script trigger_71_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_71_interact)
extern const unsigned char trigger_71_interact[];

#endif

#ifndef SCENE_1_H
#define SCENE_1_H

// Scene: Logo

#include "gbs_types.h"

BANKREF_EXTERN(scene_1)
extern const struct scene_t scene_1;

#endif

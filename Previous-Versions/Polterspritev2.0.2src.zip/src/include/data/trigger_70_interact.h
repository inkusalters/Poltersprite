#ifndef TRIGGER_70_INTERACT_H
#define TRIGGER_70_INTERACT_H

// Script trigger_70_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_70_interact)
extern const unsigned char trigger_70_interact[];

#endif

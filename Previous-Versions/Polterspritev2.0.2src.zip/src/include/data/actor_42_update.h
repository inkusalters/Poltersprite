#ifndef ACTOR_42_UPDATE_H
#define ACTOR_42_UPDATE_H

// Script actor_42_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_42_update)
extern const unsigned char actor_42_update[];

#endif

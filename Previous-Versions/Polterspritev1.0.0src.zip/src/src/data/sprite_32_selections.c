#pragma bank 255
// SpriteSheet: 32-selections

#include "gbs_types.h"
#include "data/sprite_32_selections_tileset.h"


BANKREF(sprite_32_selections)

#define SPRITE_11_STATE_DEFAULT 0
#define SPRITE_11_STATE_STRIKETHROUGH24 0
#define SPRITE_11_STATE_CIRCLED24 0
#define SPRITE_11_STATE_HANDPRINT 0
#define SPRITE_11_STATE_CUP_UPRIGHT 0
#define SPRITE_11_STATE_CUP_KNOCKED 0
#define SPRITE_11_STATE_FRAME_UPRIGHT 0
#define SPRITE_11_STATE_FRAME_KNOCKED 0
#define SPRITE_11_STATE_BONE 0
#define SPRITE_11_STATE_SKULL 0
#define SPRITE_11_STATE_EMF 0
#define SPRITE_11_STATE_SPIRIT_BOX 0
#define SPRITE_11_STATE_THERMOMETER 0
#define SPRITE_11_STATE_NOTEBOOK 0
#define SPRITE_11_STATE_CHECKED 0
#define SPRITE_11_STATE_STRIKETHROUGH32 8
#define SPRITE_11_STATE_CIRCLED32 16
#define SPRITE_11_STATE_STRIKETHROUGH56 0
#define SPRITE_11_STATE_CIRCLED56 0
#define SPRITE_11_STATE_LOSE 0
#define SPRITE_11_STATE_WIN 0

const metasprite_t sprite_32_selections_metasprite_0[]  = {
    {metasprite_end}
};

const metasprite_t sprite_32_selections_metasprite_1[]  = {
    { 0, 16, 4, 0 }, { 0, -8, 4, 0 }, { 0, -8, 4, 0 }, { 0, -8, 4, 0 },
    {metasprite_end}
};

const metasprite_t sprite_32_selections_metasprite_2[]  = {
    { 0, 16, 2, 32 }, { 0, -8, 0, 0 }, { 0, -8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t * const sprite_32_selections_metasprites[] = {
    sprite_32_selections_metasprite_0,
    sprite_32_selections_metasprite_1,
    sprite_32_selections_metasprite_2
};

const struct animation_t sprite_32_selections_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 2,
        .end = 2
    }
};

const UWORD sprite_32_selections_animations_lookup[] = {
    SPRITE_11_STATE_DEFAULT,
    SPRITE_11_STATE_STRIKETHROUGH24,
    SPRITE_11_STATE_CIRCLED24,
    SPRITE_11_STATE_HANDPRINT,
    SPRITE_11_STATE_CUP_UPRIGHT,
    SPRITE_11_STATE_CUP_KNOCKED,
    SPRITE_11_STATE_FRAME_UPRIGHT,
    SPRITE_11_STATE_FRAME_KNOCKED,
    SPRITE_11_STATE_BONE,
    SPRITE_11_STATE_SKULL,
    SPRITE_11_STATE_EMF,
    SPRITE_11_STATE_SPIRIT_BOX,
    SPRITE_11_STATE_THERMOMETER,
    SPRITE_11_STATE_NOTEBOOK,
    SPRITE_11_STATE_CHECKED,
    SPRITE_11_STATE_STRIKETHROUGH32,
    SPRITE_11_STATE_CIRCLED32
};

const struct spritesheet_t sprite_32_selections = {
    .n_metasprites = 3,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_32_selections_metasprites,
    .animations = sprite_32_selections_animations,
    .animations_lookup = sprite_32_selections_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_32_selections_tileset),
    .cgb_tileset = { NULL, NULL }
};

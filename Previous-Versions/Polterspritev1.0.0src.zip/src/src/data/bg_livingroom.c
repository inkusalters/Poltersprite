#pragma bank 255

// Background: livingroom

#include "gbs_types.h"
#include "data/bg_livingroom_tileset.h"
#include "data/bg_livingroom_tilemap.h"

BANKREF(bg_livingroom)

const struct background_t bg_livingroom = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_livingroom_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_livingroom_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};

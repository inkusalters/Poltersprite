#pragma bank 255

// Scene: Garage
// Actors

#include "gbs_types.h"
#include "data/sprite_ghost1.h"
#include "data/actor_2_update.h"
#include "data/actor_2_interact.h"
#include "data/sprite_24_selections.h"
#include "data/actor_24_update.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_bones.h"
#include "data/actor_35_interact.h"

BANKREF(scene_8_actors)

const struct actor_t scene_8_actors[] = {
    {
        // GarageGhost,
        .pos = {
            .x = 88 * 16,
            .y = 96 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_ghost1),
        .move_speed = 16,
        .anim_tick = 7,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_2_update),
        .script = TO_FAR_PTR_T(actor_2_interact),
        .reserve_tiles = 36
    },
    {
        // Actor 2,
        .pos = {
            .x = 120 * 16,
            .y = 136 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_24_selections),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_24_update),
        .reserve_tiles = 0
    },
    {
        // Actor 3,
        .pos = {
            .x = 40 * 16,
            .y = 32 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_ghost_events),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .reserve_tiles = 0
    },
    {
        // Actor 4,
        .pos = {
            .x = 128 * 16,
            .y = 112 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_ghost_events),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .reserve_tiles = 0
    },
    {
        // Bone,
        .pos = {
            .x = 16 * 16,
            .y = 88 * 16
        },
        .bounds = {
            .left = 8,
            .bottom = 7,
            .right = 15,
            .top = 0
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bones),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(actor_35_interact),
        .reserve_tiles = 0
    }
};

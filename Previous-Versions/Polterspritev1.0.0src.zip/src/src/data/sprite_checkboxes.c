#pragma bank 255
// SpriteSheet: checkboxes

#include "gbs_types.h"
#include "data/sprite_checkboxes_tileset.h"


BANKREF(sprite_checkboxes)

#define SPRITE_10_STATE_DEFAULT 0
#define SPRITE_10_STATE_STRIKETHROUGH24 0
#define SPRITE_10_STATE_CIRCLED24 0
#define SPRITE_10_STATE_HANDPRINT 0
#define SPRITE_10_STATE_CUP_UPRIGHT 0
#define SPRITE_10_STATE_CUP_KNOCKED 0
#define SPRITE_10_STATE_FRAME_UPRIGHT 0
#define SPRITE_10_STATE_FRAME_KNOCKED 0
#define SPRITE_10_STATE_BONE 0
#define SPRITE_10_STATE_SKULL 0
#define SPRITE_10_STATE_EMF 0
#define SPRITE_10_STATE_SPIRIT_BOX 0
#define SPRITE_10_STATE_THERMOMETER 0
#define SPRITE_10_STATE_NOTEBOOK 0
#define SPRITE_10_STATE_CHECKED 8
#define SPRITE_10_STATE_STRIKETHROUGH32 0
#define SPRITE_10_STATE_CIRCLED32 0
#define SPRITE_10_STATE_STRIKETHROUGH56 0
#define SPRITE_10_STATE_CIRCLED56 0
#define SPRITE_10_STATE_LOSE 0
#define SPRITE_10_STATE_WIN 0

const metasprite_t sprite_checkboxes_metasprite_0[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 0, 32 },
    {metasprite_end}
};

const metasprite_t sprite_checkboxes_metasprite_1[]  = {
    { 0, 8, 2, 0 }, { 0, -8, 2, 32 },
    {metasprite_end}
};

const metasprite_t * const sprite_checkboxes_metasprites[] = {
    sprite_checkboxes_metasprite_0,
    sprite_checkboxes_metasprite_1
};

const struct animation_t sprite_checkboxes_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 1,
        .end = 1
    }
};

const UWORD sprite_checkboxes_animations_lookup[] = {
    SPRITE_10_STATE_DEFAULT,
    SPRITE_10_STATE_STRIKETHROUGH24,
    SPRITE_10_STATE_CIRCLED24,
    SPRITE_10_STATE_HANDPRINT,
    SPRITE_10_STATE_CUP_UPRIGHT,
    SPRITE_10_STATE_CUP_KNOCKED,
    SPRITE_10_STATE_FRAME_UPRIGHT,
    SPRITE_10_STATE_FRAME_KNOCKED,
    SPRITE_10_STATE_BONE,
    SPRITE_10_STATE_SKULL,
    SPRITE_10_STATE_EMF,
    SPRITE_10_STATE_SPIRIT_BOX,
    SPRITE_10_STATE_THERMOMETER,
    SPRITE_10_STATE_NOTEBOOK,
    SPRITE_10_STATE_CHECKED
};

const struct spritesheet_t sprite_checkboxes = {
    .n_metasprites = 2,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_checkboxes_metasprites,
    .animations = sprite_checkboxes_animations,
    .animations_lookup = sprite_checkboxes_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_checkboxes_tileset),
    .cgb_tileset = { NULL, NULL }
};

#pragma bank 255

// Scene: Garage
// Triggers

#include "gbs_types.h"
#include "data/trigger_5_interact.h"
#include "data/trigger_22_interact.h"
#include "data/trigger_23_interact.h"
#include "data/trigger_24_interact.h"

BANKREF(scene_8_triggers)

const struct trigger_t scene_8_triggers[] = {
    {
        // Trigger 1,
        .x = 8,
        .y = 4,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_5_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 14,
        .y = 3,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_22_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 3,
        .x = 14,
        .y = 8,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_23_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    },
    {
        // Trigger 4,
        .x = 11,
        .y = 11,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_24_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT | TRIGGER_HAS_LEAVE_SCRIPT
    }
};

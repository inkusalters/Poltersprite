#ifndef SCENE_11_INIT_H
#define SCENE_11_INIT_H

// Script scene_11_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_11_init)
extern const unsigned char scene_11_init[];

#endif

#ifndef SCRIPT_INPUT_19_H
#define SCRIPT_INPUT_19_H

// Script script_input_19

#include "gbs_types.h"

BANKREF_EXTERN(script_input_19)
extern const unsigned char script_input_19[];

#endif

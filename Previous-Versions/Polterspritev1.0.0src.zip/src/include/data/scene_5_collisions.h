#ifndef SCENE_5_COLLISIONS_H
#define SCENE_5_COLLISIONS_H

// Scene: Bedroom
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_5_collisions)
extern const unsigned char scene_5_collisions[];

#endif

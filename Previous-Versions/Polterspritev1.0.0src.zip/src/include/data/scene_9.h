#ifndef SCENE_9_H
#define SCENE_9_H

// Scene: Truck

#include "gbs_types.h"

BANKREF_EXTERN(scene_9)
extern const struct scene_t scene_9;

#endif

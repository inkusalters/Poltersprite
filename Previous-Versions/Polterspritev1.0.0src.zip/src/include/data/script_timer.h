#ifndef SCRIPT_TIMER_H
#define SCRIPT_TIMER_H

// Script script_timer

#include "gbs_types.h"

BANKREF_EXTERN(script_timer)
extern const unsigned char script_timer[];

#endif

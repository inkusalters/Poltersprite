#ifndef SCRIPT_6_H
#define SCRIPT_6_H

// Script script_6

#include "gbs_types.h"

BANKREF_EXTERN(script_6)
extern const unsigned char script_6[];

#endif

#ifndef __sound_legacy_0_5_INCLUDE__
#define __sound_legacy_0_5_INCLUDE__

#include <gbdk/platform.h>
#include <stdint.h>

#define MUTE_MASK_sound_legacy_0_5 0b00000001

BANKREF_EXTERN(sound_legacy_0_5)
extern const uint8_t sound_legacy_0_5[];
extern void __mute_mask_sound_legacy_0_5;

#endif

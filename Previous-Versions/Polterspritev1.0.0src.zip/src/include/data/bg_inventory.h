#ifndef BG_INVENTORY_H
#define BG_INVENTORY_H

// Background: inventory

#include "gbs_types.h"

BANKREF_EXTERN(bg_inventory)
extern const struct background_t bg_inventory;

#endif

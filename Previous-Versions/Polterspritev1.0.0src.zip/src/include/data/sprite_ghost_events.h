#ifndef SPRITE_GHOST_EVENTS_H
#define SPRITE_GHOST_EVENTS_H

// SpriteSheet: ghost-events

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ghost_events)
extern const struct spritesheet_t sprite_ghost_events;

#endif

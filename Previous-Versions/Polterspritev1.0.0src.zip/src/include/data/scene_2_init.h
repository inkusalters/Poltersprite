#ifndef SCENE_2_INIT_H
#define SCENE_2_INIT_H

// Script scene_2_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_2_init)
extern const unsigned char scene_2_init[];

#endif

#ifndef SPRITE_56_SELECTIONS_TILESET_H
#define SPRITE_56_SELECTIONS_TILESET_H

// Tileset: sprite_56_selections_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_56_selections_tileset)
extern const struct tileset_t sprite_56_selections_tileset;

#endif

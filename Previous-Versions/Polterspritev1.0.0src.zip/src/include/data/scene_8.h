#ifndef SCENE_8_H
#define SCENE_8_H

// Scene: Garage

#include "gbs_types.h"

BANKREF_EXTERN(scene_8)
extern const struct scene_t scene_8;

#endif

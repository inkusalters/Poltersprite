#ifndef TRIGGER_20_INTERACT_H
#define TRIGGER_20_INTERACT_H

// Script trigger_20_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_20_interact)
extern const unsigned char trigger_20_interact[];

#endif

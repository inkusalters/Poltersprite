#ifndef ACTOR_2_UPDATE_H
#define ACTOR_2_UPDATE_H

// Script actor_2_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_2_update)
extern const unsigned char actor_2_update[];

#endif

#ifndef SCENE_10_H
#define SCENE_10_H

// Scene: Notebook

#include "gbs_types.h"

BANKREF_EXTERN(scene_10)
extern const struct scene_t scene_10;

#endif

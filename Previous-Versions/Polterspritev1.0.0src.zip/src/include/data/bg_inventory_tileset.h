#ifndef BG_INVENTORY_TILESET_H
#define BG_INVENTORY_TILESET_H

// Tileset: bg_inventory_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_inventory_tileset)
extern const struct tileset_t bg_inventory_tileset;

#endif

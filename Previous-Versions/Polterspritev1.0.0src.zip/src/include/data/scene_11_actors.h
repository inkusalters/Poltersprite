#ifndef SCENE_11_ACTORS_H
#define SCENE_11_ACTORS_H

// Scene: Game Over
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_11_actors)
extern const struct actor_t scene_11_actors[];

#endif

#ifndef BG_BATHROOM_TILESET_H
#define BG_BATHROOM_TILESET_H

// Tileset: bg_bathroom_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_bathroom_tileset)
extern const struct tileset_t bg_bathroom_tileset;

#endif

#ifndef SCRIPT_INPUT_11_H
#define SCRIPT_INPUT_11_H

// Script script_input_11

#include "gbs_types.h"

BANKREF_EXTERN(script_input_11)
extern const unsigned char script_input_11[];

#endif

#ifndef BG_LOGO_TILESET_H
#define BG_LOGO_TILESET_H

// Tileset: bg_logo_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_logo_tileset)
extern const struct tileset_t bg_logo_tileset;

#endif

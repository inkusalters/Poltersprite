#ifndef __sound_legacy_0_10_INCLUDE__
#define __sound_legacy_0_10_INCLUDE__

#include <gbdk/platform.h>
#include <stdint.h>

#define MUTE_MASK_sound_legacy_0_10 0b00000001

BANKREF_EXTERN(sound_legacy_0_10)
extern const uint8_t sound_legacy_0_10[];
extern void __mute_mask_sound_legacy_0_10;

#endif

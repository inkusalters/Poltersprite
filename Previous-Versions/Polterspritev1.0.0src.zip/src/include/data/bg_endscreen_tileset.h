#ifndef BG_ENDSCREEN_TILESET_H
#define BG_ENDSCREEN_TILESET_H

// Tileset: bg_endscreen_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_endscreen_tileset)
extern const struct tileset_t bg_endscreen_tileset;

#endif

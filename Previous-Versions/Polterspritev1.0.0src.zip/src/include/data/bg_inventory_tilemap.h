#ifndef BG_INVENTORY_TILEMAP_H
#define BG_INVENTORY_TILEMAP_H

// Tilemap bg_inventory_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_inventory_tilemap)
extern const unsigned char bg_inventory_tilemap[];

#endif

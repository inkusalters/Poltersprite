#ifndef ACTOR_16_INTERACT_H
#define ACTOR_16_INTERACT_H

// Script actor_16_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_16_interact)
extern const unsigned char actor_16_interact[];

#endif

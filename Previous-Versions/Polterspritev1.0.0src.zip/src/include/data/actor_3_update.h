#ifndef ACTOR_3_UPDATE_H
#define ACTOR_3_UPDATE_H

// Script actor_3_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_3_update)
extern const unsigned char actor_3_update[];

#endif

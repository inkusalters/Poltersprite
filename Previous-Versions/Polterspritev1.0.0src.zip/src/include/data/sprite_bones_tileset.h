#ifndef SPRITE_BONES_TILESET_H
#define SPRITE_BONES_TILESET_H

// Tileset: sprite_bones_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bones_tileset)
extern const struct tileset_t sprite_bones_tileset;

#endif

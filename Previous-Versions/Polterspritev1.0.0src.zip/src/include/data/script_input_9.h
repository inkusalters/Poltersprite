#ifndef SCRIPT_INPUT_9_H
#define SCRIPT_INPUT_9_H

// Script script_input_9

#include "gbs_types.h"

BANKREF_EXTERN(script_input_9)
extern const unsigned char script_input_9[];

#endif

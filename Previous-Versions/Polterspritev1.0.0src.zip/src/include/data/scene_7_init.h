#ifndef SCENE_7_INIT_H
#define SCENE_7_INIT_H

// Script scene_7_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_7_init)
extern const unsigned char scene_7_init[];

#endif

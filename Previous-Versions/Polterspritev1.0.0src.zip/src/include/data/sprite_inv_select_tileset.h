#ifndef SPRITE_INV_SELECT_TILESET_H
#define SPRITE_INV_SELECT_TILESET_H

// Tileset: sprite_inv_select_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_inv_select_tileset)
extern const struct tileset_t sprite_inv_select_tileset;

#endif

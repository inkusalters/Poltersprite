#ifndef SPRITE_24_SELECTIONS_H
#define SPRITE_24_SELECTIONS_H

// SpriteSheet: 24-selections

#include "gbs_types.h"

BANKREF_EXTERN(sprite_24_selections)
extern const struct spritesheet_t sprite_24_selections;

#endif

#ifndef BG_GARAGE_TILEMAP_H
#define BG_GARAGE_TILEMAP_H

// Tilemap bg_garage_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_garage_tilemap)
extern const unsigned char bg_garage_tilemap[];

#endif

#ifndef BG_LOGO_H
#define BG_LOGO_H

// Background: logo

#include "gbs_types.h"

BANKREF_EXTERN(bg_logo)
extern const struct background_t bg_logo;

#endif

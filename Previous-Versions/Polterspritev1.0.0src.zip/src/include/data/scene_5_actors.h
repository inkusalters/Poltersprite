#ifndef SCENE_5_ACTORS_H
#define SCENE_5_ACTORS_H

// Scene: Bedroom
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_5_actors)
extern const struct actor_t scene_5_actors[];

#endif

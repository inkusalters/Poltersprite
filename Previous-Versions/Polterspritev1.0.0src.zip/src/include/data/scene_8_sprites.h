#ifndef SCENE_8_SPRITES_H
#define SCENE_8_SPRITES_H

// Scene: Garage
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_8_sprites)
extern const far_ptr_t scene_8_sprites[];

#endif

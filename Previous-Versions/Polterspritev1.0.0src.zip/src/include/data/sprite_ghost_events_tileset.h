#ifndef SPRITE_GHOST_EVENTS_TILESET_H
#define SPRITE_GHOST_EVENTS_TILESET_H

// Tileset: sprite_ghost_events_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ghost_events_tileset)
extern const struct tileset_t sprite_ghost_events_tileset;

#endif

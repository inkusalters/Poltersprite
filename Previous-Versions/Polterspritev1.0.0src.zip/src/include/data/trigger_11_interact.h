#ifndef TRIGGER_11_INTERACT_H
#define TRIGGER_11_INTERACT_H

// Script trigger_11_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_11_interact)
extern const unsigned char trigger_11_interact[];

#endif

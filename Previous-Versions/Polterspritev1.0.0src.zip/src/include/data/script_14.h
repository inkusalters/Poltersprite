#ifndef SCRIPT_14_H
#define SCRIPT_14_H

// Script script_14

#include "gbs_types.h"

BANKREF_EXTERN(script_14)
extern const unsigned char script_14[];

#endif

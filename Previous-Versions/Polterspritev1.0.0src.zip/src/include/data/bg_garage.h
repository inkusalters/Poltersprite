#ifndef BG_GARAGE_H
#define BG_GARAGE_H

// Background: garage

#include "gbs_types.h"

BANKREF_EXTERN(bg_garage)
extern const struct background_t bg_garage;

#endif

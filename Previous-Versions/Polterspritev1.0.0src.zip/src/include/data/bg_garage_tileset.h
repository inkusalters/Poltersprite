#ifndef BG_GARAGE_TILESET_H
#define BG_GARAGE_TILESET_H

// Tileset: bg_garage_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_garage_tileset)
extern const struct tileset_t bg_garage_tileset;

#endif

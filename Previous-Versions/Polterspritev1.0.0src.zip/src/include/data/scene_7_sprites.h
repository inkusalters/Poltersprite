#ifndef SCENE_7_SPRITES_H
#define SCENE_7_SPRITES_H

// Scene: Equipment
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_7_sprites)
extern const far_ptr_t scene_7_sprites[];

#endif

#ifndef SPRITE_32_SELECTIONS_H
#define SPRITE_32_SELECTIONS_H

// SpriteSheet: 32-selections

#include "gbs_types.h"

BANKREF_EXTERN(sprite_32_selections)
extern const struct spritesheet_t sprite_32_selections;

#endif

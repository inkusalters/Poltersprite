#ifndef SCENE_8_TRIGGERS_H
#define SCENE_8_TRIGGERS_H

// Scene: Garage
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_8_triggers)
extern const struct trigger_t scene_8_triggers[];

#endif

#ifndef TRIGGER_0_INTERACT_H
#define TRIGGER_0_INTERACT_H

// Script trigger_0_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_0_interact)
extern const unsigned char trigger_0_interact[];

#endif

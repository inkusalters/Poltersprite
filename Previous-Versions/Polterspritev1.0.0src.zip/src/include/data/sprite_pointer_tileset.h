#ifndef SPRITE_POINTER_TILESET_H
#define SPRITE_POINTER_TILESET_H

// Tileset: sprite_pointer_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_pointer_tileset)
extern const struct tileset_t sprite_pointer_tileset;

#endif

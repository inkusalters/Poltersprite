#ifndef SCENE_10_INIT_H
#define SCENE_10_INIT_H

// Script scene_10_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_10_init)
extern const unsigned char scene_10_init[];

#endif

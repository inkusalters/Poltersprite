#ifndef BG_LIVINGROOM_H
#define BG_LIVINGROOM_H

// Background: livingroom

#include "gbs_types.h"

BANKREF_EXTERN(bg_livingroom)
extern const struct background_t bg_livingroom;

#endif

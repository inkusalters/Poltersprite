#ifndef TRIGGER_12_INTERACT_H
#define TRIGGER_12_INTERACT_H

// Script trigger_12_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_12_interact)
extern const unsigned char trigger_12_interact[];

#endif

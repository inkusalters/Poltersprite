#ifndef SCRIPT_INPUT_12_H
#define SCRIPT_INPUT_12_H

// Script script_input_12

#include "gbs_types.h"

BANKREF_EXTERN(script_input_12)
extern const unsigned char script_input_12[];

#endif

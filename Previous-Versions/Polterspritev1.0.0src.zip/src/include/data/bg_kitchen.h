#ifndef BG_KITCHEN_H
#define BG_KITCHEN_H

// Background: kitchen

#include "gbs_types.h"

BANKREF_EXTERN(bg_kitchen)
extern const struct background_t bg_kitchen;

#endif

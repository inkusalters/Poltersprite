#pragma bank 255

// Scene: Notebook
// Sprites

#include "gbs_types.h"
#include "data/sprite_checkboxes.h"
#include "data/sprite_32_selections.h"
#include "data/sprite_56_selections.h"
#include "data/sprite_24_selections.h"

BANKREF(scene_10_sprites)

const far_ptr_t scene_10_sprites[] = {
    TO_FAR_PTR_T(sprite_checkboxes),
    TO_FAR_PTR_T(sprite_32_selections),
    TO_FAR_PTR_T(sprite_56_selections),
    TO_FAR_PTR_T(sprite_24_selections)
};

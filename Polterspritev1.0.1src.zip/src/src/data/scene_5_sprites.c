#pragma bank 255

// Scene: Bedroom
// Sprites

#include "gbs_types.h"
#include "data/sprite_24_selections.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_bones.h"

BANKREF(scene_5_sprites)

const far_ptr_t scene_5_sprites[] = {
    TO_FAR_PTR_T(sprite_24_selections),
    TO_FAR_PTR_T(sprite_ghost_events),
    TO_FAR_PTR_T(sprite_bones)
};

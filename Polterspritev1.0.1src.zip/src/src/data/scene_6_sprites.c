#pragma bank 255

// Scene: Bathroom
// Sprites

#include "gbs_types.h"
#include "data/sprite_24_selections.h"
#include "data/sprite_ghost_events.h"
#include "data/sprite_bones.h"

BANKREF(scene_6_sprites)

const far_ptr_t scene_6_sprites[] = {
    TO_FAR_PTR_T(sprite_24_selections),
    TO_FAR_PTR_T(sprite_ghost_events),
    TO_FAR_PTR_T(sprite_bones)
};

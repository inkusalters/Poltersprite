#pragma bank 255
// SpriteSheet: ghost2

#include "gbs_types.h"
#include "data/sprite_ghost2_tileset.h"


BANKREF(sprite_ghost2)

#define SPRITE_1_STATE_DEFAULT 0
#define SPRITE_1_STATE_STRIKETHROUGH24 0
#define SPRITE_1_STATE_CIRCLED24 0
#define SPRITE_1_STATE_HANDPRINT 0
#define SPRITE_1_STATE_CUP_UPRIGHT 0
#define SPRITE_1_STATE_CUP_KNOCKED 0
#define SPRITE_1_STATE_FRAME_UPRIGHT 0
#define SPRITE_1_STATE_FRAME_KNOCKED 0
#define SPRITE_1_STATE_BONE 0
#define SPRITE_1_STATE_SKULL 0
#define SPRITE_1_STATE_EMF 0
#define SPRITE_1_STATE_SPIRIT_BOX 0
#define SPRITE_1_STATE_THERMOMETER 0
#define SPRITE_1_STATE_NOTEBOOK 0
#define SPRITE_1_STATE_CHECKED 0
#define SPRITE_1_STATE_STRIKETHROUGH32 0
#define SPRITE_1_STATE_CIRCLED32 0
#define SPRITE_1_STATE_STRIKETHROUGH56 0
#define SPRITE_1_STATE_CIRCLED56 0
#define SPRITE_1_STATE_LOSE 0
#define SPRITE_1_STATE_WIN 0

const metasprite_t sprite_ghost2_metasprite_0[]  = {
    { 0, 8, 8, 0 }, { 0, -8, 10, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_1[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_2[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_3[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_4[]  = {
    { 0, 8, 28, 0 }, { 0, -8, 30, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_5[]  = {
    { 0, 8, 30, 32 }, { 0, -8, 28, 32 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_6[]  = {
    { 0, 8, 12, 0 }, { 0, -8, 14, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_7[]  = {
    { 0, 8, 16, 0 }, { 0, -8, 18, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_8[]  = {
    { 0, 0, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_9[]  = {
    { 0, 8, 20, 0 }, { 0, -8, 22, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_10[]  = {
    { 0, 8, 24, 0 }, { 0, -8, 26, 0 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_11[]  = {
    { 0, 0, 12, 32 }, { 0, 8, 14, 32 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_12[]  = {
    { 0, 0, 16, 32 }, { 0, 8, 18, 32 },
    {metasprite_end}
};

const metasprite_t sprite_ghost2_metasprite_13[]  = {
    { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t * const sprite_ghost2_metasprites[] = {
    sprite_ghost2_metasprite_0,
    sprite_ghost2_metasprite_1,
    sprite_ghost2_metasprite_2,
    sprite_ghost2_metasprite_3,
    sprite_ghost2_metasprite_4,
    sprite_ghost2_metasprite_0,
    sprite_ghost2_metasprite_5,
    sprite_ghost2_metasprite_0,
    sprite_ghost2_metasprite_6,
    sprite_ghost2_metasprite_1,
    sprite_ghost2_metasprite_7,
    sprite_ghost2_metasprite_8,
    sprite_ghost2_metasprite_9,
    sprite_ghost2_metasprite_2,
    sprite_ghost2_metasprite_10,
    sprite_ghost2_metasprite_2,
    sprite_ghost2_metasprite_11,
    sprite_ghost2_metasprite_3,
    sprite_ghost2_metasprite_12,
    sprite_ghost2_metasprite_13
};

const struct animation_t sprite_ghost2_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 3,
        .end = 3
    },
    {
        .start = 4,
        .end = 7
    },
    {
        .start = 8,
        .end = 11
    },
    {
        .start = 12,
        .end = 15
    },
    {
        .start = 16,
        .end = 19
    }
};

const UWORD sprite_ghost2_animations_lookup[] = {
    SPRITE_1_STATE_DEFAULT
};

const struct spritesheet_t sprite_ghost2 = {
    .n_metasprites = 20,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_ghost2_metasprites,
    .animations = sprite_ghost2_animations,
    .animations_lookup = sprite_ghost2_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_ghost2_tileset),
    .cgb_tileset = { NULL, NULL }
};

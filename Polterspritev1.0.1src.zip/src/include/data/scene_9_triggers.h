#ifndef SCENE_9_TRIGGERS_H
#define SCENE_9_TRIGGERS_H

// Scene: Truck
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_9_triggers)
extern const struct trigger_t scene_9_triggers[];

#endif

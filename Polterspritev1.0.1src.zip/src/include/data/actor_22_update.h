#ifndef ACTOR_22_UPDATE_H
#define ACTOR_22_UPDATE_H

// Script actor_22_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_22_update)
extern const unsigned char actor_22_update[];

#endif

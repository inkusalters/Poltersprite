#ifndef SCRIPT_7_H
#define SCRIPT_7_H

// Script script_7

#include "gbs_types.h"

BANKREF_EXTERN(script_7)
extern const unsigned char script_7[];

#endif

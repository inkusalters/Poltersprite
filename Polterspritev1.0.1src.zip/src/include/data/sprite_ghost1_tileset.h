#ifndef SPRITE_GHOST1_TILESET_H
#define SPRITE_GHOST1_TILESET_H

// Tileset: sprite_ghost1_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ghost1_tileset)
extern const struct tileset_t sprite_ghost1_tileset;

#endif

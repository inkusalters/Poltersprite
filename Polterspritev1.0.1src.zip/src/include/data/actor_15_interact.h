#ifndef ACTOR_15_INTERACT_H
#define ACTOR_15_INTERACT_H

// Script actor_15_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_15_interact)
extern const unsigned char actor_15_interact[];

#endif

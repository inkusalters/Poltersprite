#ifndef SPRITE_56_SELECTIONS_H
#define SPRITE_56_SELECTIONS_H

// SpriteSheet: 56-selections

#include "gbs_types.h"

BANKREF_EXTERN(sprite_56_selections)
extern const struct spritesheet_t sprite_56_selections;

#endif

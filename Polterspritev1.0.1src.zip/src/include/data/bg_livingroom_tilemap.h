#ifndef BG_LIVINGROOM_TILEMAP_H
#define BG_LIVINGROOM_TILEMAP_H

// Tilemap bg_livingroom_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_livingroom_tilemap)
extern const unsigned char bg_livingroom_tilemap[];

#endif

#ifndef SPRITE_CHECKBOXES_TILESET_H
#define SPRITE_CHECKBOXES_TILESET_H

// Tileset: sprite_checkboxes_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_checkboxes_tileset)
extern const struct tileset_t sprite_checkboxes_tileset;

#endif

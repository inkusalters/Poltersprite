#ifndef SPRITE_INV_SELECT_H
#define SPRITE_INV_SELECT_H

// SpriteSheet: inv-select

#include "gbs_types.h"

BANKREF_EXTERN(sprite_inv_select)
extern const struct spritesheet_t sprite_inv_select;

#endif

#ifndef SPRITE_ACTOR_ANIMATED_H
#define SPRITE_ACTOR_ANIMATED_H

// SpriteSheet: actor_animated

#include "gbs_types.h"

BANKREF_EXTERN(sprite_actor_animated)
extern const struct spritesheet_t sprite_actor_animated;

#endif

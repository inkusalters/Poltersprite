#ifndef SCENE_9_COLLISIONS_H
#define SCENE_9_COLLISIONS_H

// Scene: Truck
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_9_collisions)
extern const unsigned char scene_9_collisions[];

#endif

#ifndef SCENE_TYPES_H
#define SCENE_TYPES_H

typedef enum {
    SCENE_TYPE_TOPDOWN = 0,
    SCENE_TYPE_LOGO
} scene_type_e;
#endif

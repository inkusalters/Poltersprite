#ifndef SCENE_5_SPRITES_H
#define SCENE_5_SPRITES_H

// Scene: Bedroom
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_5_sprites)
extern const far_ptr_t scene_5_sprites[];

#endif

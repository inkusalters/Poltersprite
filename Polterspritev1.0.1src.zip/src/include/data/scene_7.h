#ifndef SCENE_7_H
#define SCENE_7_H

// Scene: Equipment

#include "gbs_types.h"

BANKREF_EXTERN(scene_7)
extern const struct scene_t scene_7;

#endif

#ifndef STATES_DEFINES_H
#define STATES_DEFINES_H

#define INPUT_TOPDOWN_INTERACT           INPUT_A

#endif

#ifndef SCENE_6_COLLISIONS_H
#define SCENE_6_COLLISIONS_H

// Scene: Bathroom
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_6_collisions)
extern const unsigned char scene_6_collisions[];

#endif

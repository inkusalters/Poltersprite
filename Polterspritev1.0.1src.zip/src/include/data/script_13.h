#ifndef SCRIPT_13_H
#define SCRIPT_13_H

// Script script_13

#include "gbs_types.h"

BANKREF_EXTERN(script_13)
extern const unsigned char script_13[];

#endif

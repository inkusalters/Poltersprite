#ifndef MUSIC_DATA_H
#define MUSIC_DATA_H

extern const void __bank_song_ambient_house_Data;
extern const void song_ambient_house_Data;
extern const void __bank_song_hunting_house_Data;
extern const void song_hunting_house_Data;
extern const void __bank_song_menu_Data;
extern const void song_menu_Data;

#endif

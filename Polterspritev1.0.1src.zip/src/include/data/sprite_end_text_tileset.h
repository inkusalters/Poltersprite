#ifndef SPRITE_END_TEXT_TILESET_H
#define SPRITE_END_TEXT_TILESET_H

// Tileset: sprite_end_text_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_end_text_tileset)
extern const struct tileset_t sprite_end_text_tileset;

#endif

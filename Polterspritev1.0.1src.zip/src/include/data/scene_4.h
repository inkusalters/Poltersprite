#ifndef SCENE_4_H
#define SCENE_4_H

// Scene: Kitchen

#include "gbs_types.h"

BANKREF_EXTERN(scene_4)
extern const struct scene_t scene_4;

#endif

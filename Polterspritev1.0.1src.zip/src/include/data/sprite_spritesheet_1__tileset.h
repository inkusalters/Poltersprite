#ifndef SPRITE_SPRITESHEET_1__TILESET_H
#define SPRITE_SPRITESHEET_1__TILESET_H

// Tileset: sprite_spritesheet_1__tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_spritesheet_1__tileset)
extern const struct tileset_t sprite_spritesheet_1__tileset;

#endif

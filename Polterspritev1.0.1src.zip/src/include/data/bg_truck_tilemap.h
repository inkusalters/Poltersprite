#ifndef BG_TRUCK_TILEMAP_H
#define BG_TRUCK_TILEMAP_H

// Tilemap bg_truck_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_truck_tilemap)
extern const unsigned char bg_truck_tilemap[];

#endif

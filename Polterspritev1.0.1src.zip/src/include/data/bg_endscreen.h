#ifndef BG_ENDSCREEN_H
#define BG_ENDSCREEN_H

// Background: endscreen

#include "gbs_types.h"

BANKREF_EXTERN(bg_endscreen)
extern const struct background_t bg_endscreen;

#endif

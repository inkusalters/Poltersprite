#ifndef SCENE_8_COLLISIONS_H
#define SCENE_8_COLLISIONS_H

// Scene: Garage
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_8_collisions)
extern const unsigned char scene_8_collisions[];

#endif

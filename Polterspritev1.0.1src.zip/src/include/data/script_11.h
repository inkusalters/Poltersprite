#ifndef SCRIPT_11_H
#define SCRIPT_11_H

// Script script_11

#include "gbs_types.h"

BANKREF_EXTERN(script_11)
extern const unsigned char script_11[];

#endif

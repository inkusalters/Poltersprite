#ifndef SCENE_3_TRIGGERS_H
#define SCENE_3_TRIGGERS_H

// Scene: Living Room
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_triggers)
extern const struct trigger_t scene_3_triggers[];

#endif

#ifndef __sound_legacy_0_15_INCLUDE__
#define __sound_legacy_0_15_INCLUDE__

#include <gbdk/platform.h>
#include <stdint.h>

#define MUTE_MASK_sound_legacy_0_15 0b00000001

BANKREF_EXTERN(sound_legacy_0_15)
extern const uint8_t sound_legacy_0_15[];
extern void __mute_mask_sound_legacy_0_15;

#endif

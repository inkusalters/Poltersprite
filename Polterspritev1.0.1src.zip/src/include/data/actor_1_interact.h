#ifndef ACTOR_1_INTERACT_H
#define ACTOR_1_INTERACT_H

// Script actor_1_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_1_interact)
extern const unsigned char actor_1_interact[];

#endif

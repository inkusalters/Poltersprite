#ifndef SPRITE_24_SELECTIONS_TILESET_H
#define SPRITE_24_SELECTIONS_TILESET_H

// Tileset: sprite_24_selections_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_24_selections_tileset)
extern const struct tileset_t sprite_24_selections_tileset;

#endif

#ifndef SCRIPT_12_H
#define SCRIPT_12_H

// Script script_12

#include "gbs_types.h"

BANKREF_EXTERN(script_12)
extern const unsigned char script_12[];

#endif

#ifndef SCRIPT_5_H
#define SCRIPT_5_H

// Script script_5

#include "gbs_types.h"

BANKREF_EXTERN(script_5)
extern const unsigned char script_5[];

#endif

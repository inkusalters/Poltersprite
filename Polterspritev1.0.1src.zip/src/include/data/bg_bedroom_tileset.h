#ifndef BG_BEDROOM_TILESET_H
#define BG_BEDROOM_TILESET_H

// Tileset: bg_bedroom_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_bedroom_tileset)
extern const struct tileset_t bg_bedroom_tileset;

#endif

#ifndef SPRITE_SPRITESHEET_1__H
#define SPRITE_SPRITESHEET_1__H

// SpriteSheet: spritesheet

#include "gbs_types.h"

BANKREF_EXTERN(sprite_spritesheet_1_)
extern const struct spritesheet_t sprite_spritesheet_1_;

#endif

#ifndef ACTOR_23_UPDATE_H
#define ACTOR_23_UPDATE_H

// Script actor_23_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_23_update)
extern const unsigned char actor_23_update[];

#endif

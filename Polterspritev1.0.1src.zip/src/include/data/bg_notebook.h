#ifndef BG_NOTEBOOK_H
#define BG_NOTEBOOK_H

// Background: notebook

#include "gbs_types.h"

BANKREF_EXTERN(bg_notebook)
extern const struct background_t bg_notebook;

#endif

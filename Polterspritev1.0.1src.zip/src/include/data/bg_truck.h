#ifndef BG_TRUCK_H
#define BG_TRUCK_H

// Background: truck

#include "gbs_types.h"

BANKREF_EXTERN(bg_truck)
extern const struct background_t bg_truck;

#endif

#ifndef BG_TITLE_TILEMAP_H
#define BG_TITLE_TILEMAP_H

// Tilemap bg_title_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_title_tilemap)
extern const unsigned char bg_title_tilemap[];

#endif

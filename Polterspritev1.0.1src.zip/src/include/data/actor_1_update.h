#ifndef ACTOR_1_UPDATE_H
#define ACTOR_1_UPDATE_H

// Script actor_1_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_1_update)
extern const unsigned char actor_1_update[];

#endif
